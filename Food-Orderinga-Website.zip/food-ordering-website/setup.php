<?php
// Setup Script - Run this once to create required folders

$folders = [
    'images',
    'images/foods',
    'uploads'
];

echo "<h2>Setting up folders...</h2>";

foreach ($folders as $folder) {
    if (!file_exists($folder)) {
        if (mkdir($folder, 0777, true)) {
            echo "✓ Created folder: $folder<br>";
        } else {
            echo "✗ Failed to create folder: $folder<br>";
        }
    } else {
        echo "✓ Folder already exists: $folder<br>";
        // Make sure it's writable
        chmod($folder, 0777);
    }
}

echo "<br><h3>Setup Complete!</h3>";
echo "<p>All required folders have been created with proper permissions.</p>";
echo "<p><a href='admin/login.php'>Go to Admin Panel</a></p>";
?>
```

<!-- ## Steps to Fix:

1. **Create setup.php** in your project root with the code above
2. **Run it once**: `http://localhost/food-ordering-website/setup.php`
3. **This will create**:
   - `images/` folder
   - `images/foods/` folder  
   - `uploads/` folder
   
4. **After setup completes**, go back to admin panel and try uploading again

## Alternative Manual Fix:

If the script doesn't work, manually create these folders in your project:
```
food-ordering-website/
├── images/
│   └── foods/
└── uploads/ -->