<header>
    <div class="container">
        <nav class="navbar">
            <a href="<?php echo SITE_URL; ?>" class="logo">
                🍔 <?php echo SITE_NAME; ?>
            </a>

            <button class="menu-toggle" aria-label="Toggle Menu">
                ☰
            </button>

            <ul class="nav-links">
                <li><a href="<?php echo SITE_URL; ?>">Home</a></li>
                <li><a href="<?php echo SITE_URL; ?>pages/menu.php">Menu</a></li>
                <li><a href="<?php echo SITE_URL; ?>pages/about.php">About</a></li>
                <li><a href="<?php echo SITE_URL; ?>pages/contact.php">Contact</a></li>

                <?php if (isLoggedIn()): ?>
                    <?php if (isAdmin()): ?>
                        <li><a href="<?php echo SITE_URL; ?>admin/">Admin Panel</a></li>
                    <?php endif; ?>
                    <li><a href="<?php echo SITE_URL; ?>pages/profile.php">Profile</a></li>
                    <li><a href="<?php echo SITE_URL; ?>pages/order-history.php">Orders</a></li>
                    <li><a href="<?php echo SITE_URL; ?>actions/logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="<?php echo SITE_URL; ?>pages/login.php">Login</a></li>
                    <li><a href="<?php echo SITE_URL; ?>pages/register.php">Register</a></li>
                <?php endif; ?>

                <li>
                    <a href="<?php echo SITE_URL; ?>pages/cart.php" class="cart-icon">
                        🛒 Cart
                        <span class="cart-count"><?php echo getCartCount(); ?></span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</header>