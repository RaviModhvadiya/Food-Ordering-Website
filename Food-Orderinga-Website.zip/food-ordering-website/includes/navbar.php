<?php
// Navigation Bar Component
// This file can be included separately if needed, or use header.php which includes navigation
?>

<nav class="navbar">
    <a href="<?php echo SITE_URL; ?>" class="logo">
        🍔 <?php echo SITE_NAME; ?>
    </a>

    <button class="menu-toggle" aria-label="Toggle Menu">
        ☰
    </button>

    <ul class="nav-links">
        <li><a href="<?php echo SITE_URL; ?>" <?php echo (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'class="active"' : ''; ?>>Home</a></li>
        <li><a href="<?php echo SITE_URL; ?>pages/menu.php" <?php echo (basename($_SERVER['PHP_SELF']) == 'menu.php') ? 'class="active"' : ''; ?>>Menu</a></li>
        <li><a href="<?php echo SITE_URL; ?>pages/about.php" <?php echo (basename($_SERVER['PHP_SELF']) == 'about.php') ? 'class="active"' : ''; ?>>About</a></li>
        <li><a href="<?php echo SITE_URL; ?>pages/contact.php" <?php echo (basename($_SERVER['PHP_SELF']) == 'contact.php') ? 'class="active"' : ''; ?>>Contact</a></li>

        <?php if (isLoggedIn()): ?>
            <?php if (isAdmin()): ?>
                <li><a href="<?php echo SITE_URL; ?>admin/">Admin Panel</a></li>
            <?php endif; ?>
            <li><a href="<?php echo SITE_URL; ?>pages/profile.php">
                <span style="display: inline-flex; align-items: center; gap: 0.3rem;">
                    👤 <?php echo htmlspecialchars(explode(' ', $_SESSION['user_name'])[0]); ?>
                </span>
            </a></li>
            <li><a href="<?php echo SITE_URL; ?>pages/order-history.php">My Orders</a></li>
            <li><a href="<?php echo SITE_URL; ?>actions/logout.php" style="color: #ff6b6b;">Logout</a></li>
        <?php else: ?>
            <li><a href="<?php echo SITE_URL; ?>pages/login.php">Login</a></li>
            <li><a href="<?php echo SITE_URL; ?>pages/register.php" class="btn-highlight">Register</a></li>
        <?php endif; ?>

        <li>
            <a href="<?php echo SITE_URL; ?>pages/cart.php" class="cart-icon">
                🛒 Cart
                <?php $cart_count = getCartCount(); ?>
                <?php if ($cart_count > 0): ?>
                    <span class="cart-count"><?php echo $cart_count; ?></span>
                <?php endif; ?>
            </a>
        </li>
    </ul>
</nav>

<style>
/* Active navigation link */
.nav-links a.active {
    background: rgba(255, 255, 255, 0.3);
    border-radius: 5px;
}

/* Highlight button */
.btn-highlight {
    background: rgba(255, 255, 255, 0.2);
    padding: 0.5rem 1rem !important;
    border-radius: 20px;
}

.btn-highlight:hover {
    background: white !important;
    color: var(--primary-color) !important;
}
</style>