<?php
require_once '../config.php';
require_once '../functions.php';

if (!isLoggedIn()) {
    redirect('pages/login.php');
}

$user_id = $_SESSION['user_id'];
$success = '';
$error = '';

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = sanitize($_POST['full_name']);
    $phone = sanitize($_POST['phone']);
    $address = sanitize($_POST['address']);
    
    $sql = "UPDATE users SET 
            full_name = '$full_name',
            phone = '$phone',
            address = '$address'
            WHERE user_id = $user_id";
    
    if (mysqli_query($conn, $sql)) {
        $_SESSION['user_name'] = $full_name;
        $success = 'Profile updated successfully!';
    } else {
        $error = 'Failed to update profile';
    }
}

// Get user details
$sql = "SELECT * FROM users WHERE user_id = $user_id";
$result = mysqli_query($conn, $sql);
$user = mysqli_fetch_assoc($result);

// Get user statistics
$sql_orders = "SELECT COUNT(*) as total FROM orders WHERE user_id = $user_id";
$result_orders = mysqli_query($conn, $sql_orders);
$total_orders = mysqli_fetch_assoc($result_orders)['total'];

$sql_spent = "SELECT SUM(total_amount) as total FROM orders WHERE user_id = $user_id AND order_status != 'Cancelled'";
$result_spent = mysqli_query($conn, $sql_spent);
$total_spent = mysqli_fetch_assoc($result_spent)['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/animations.css">
    <link rel="stylesheet" href="../css/responsive.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <section class="py-3">
        <div class="container">
            <div class="section-title">
                <h2>My Profile</h2>
                <p>Manage your account information</p>
            </div>

            <?php if ($success): ?>
                <?php echo showSuccess($success); ?>
            <?php endif; ?>
            <?php if ($error): ?>
                <?php echo showError($error); ?>
            <?php endif; ?>

            <div style="display: grid; grid-template-columns: 300px 1fr; gap: 2rem; margin-top: 2rem;">
                <!-- Sidebar -->
                <div>
                    <div class="food-card">
                        <div class="food-card-body text-center" style="padding: 2rem;">
                            <div style="width: 100px; height: 100px; background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem; font-size: 3rem; color: white;">
                                <?php echo strtoupper(substr($user['full_name'], 0, 1)); ?>
                            </div>
                            <h3 style="margin-bottom: 0.5rem;"><?php echo htmlspecialchars($user['full_name']); ?></h3>
                            <p style="color: #666; font-size: 0.9rem;"><?php echo htmlspecialchars($user['email']); ?></p>
                            
                            <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid #eee;">
                                <div style="margin-bottom: 1rem;">
                                    <div style="font-size: 1.5rem; font-weight: bold; color: var(--primary-color);"><?php echo $total_orders; ?></div>
                                    <div style="font-size: 0.9rem; color: #666;">Total Orders</div>
                                </div>
                                <div>
                                    <div style="font-size: 1.5rem; font-weight: bold; color: var(--success-color);"><?php echo formatPrice($total_spent); ?></div>
                                    <div style="font-size: 0.9rem; color: #666;">Total Spent</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="food-card" style="margin-top: 1.5rem;">
                        <div class="food-card-body" style="padding: 1rem;">
                            <a href="order-history.php" style="display: block; padding: 0.8rem; text-decoration: none; color: inherit; border-radius: 8px; margin-bottom: 0.5rem; transition: background 0.3s;">
                                📦 Order History
                            </a>
                            <a href="profile.php" style="display: block; padding: 0.8rem; text-decoration: none; color: inherit; background: #f8f9fa; border-radius: 8px; margin-bottom: 0.5rem;">
                                👤 Profile Settings
                            </a>
                            <a href="../actions/logout.php" style="display: block; padding: 0.8rem; text-decoration: none; color: var(--danger-color); border-radius: 8px;">
                                🚪 Logout
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Main Content -->
                <div>
                    <div class="food-card">
                        <div class="food-card-body" style="padding: 2rem;">
                            <h3 style="margin-bottom: 1.5rem;">Edit Profile</h3>

                            <form method="POST">
                                <div class="form-group">
                                    <label for="full_name">Full Name *</label>
                                    <input type="text" 
                                           id="full_name" 
                                           name="full_name" 
                                           class="form-control" 
                                           value="<?php echo htmlspecialchars($user['full_name']); ?>"
                                           required>
                                </div>

                                <div class="form-group">
                                    <label for="email">Email Address</label>
                                    <input type="email" 
                                           id="email" 
                                           class="form-control" 
                                           value="<?php echo htmlspecialchars($user['email']); ?>"
                                           disabled
                                           style="background: #f8f9fa; cursor: not-allowed;">
                                    <small style="color: #666;">Email cannot be changed</small>
                                </div>

                                <div class="form-group">
                                    <label for="phone">Phone Number *</label>
                                    <input type="tel" 
                                           id="phone" 
                                           name="phone" 
                                           class="form-control" 
                                           value="<?php echo htmlspecialchars($user['phone']); ?>"
                                           required>
                                </div>

                                <div class="form-group">
                                    <label for="address">Delivery Address *</label>
                                    <textarea id="address" 
                                              name="address" 
                                              class="form-control" 
                                              rows="4"
                                              required><?php echo htmlspecialchars($user['address']); ?></textarea>
                                </div>

                                <button type="submit" class="btn btn-primary btn-ripple">
                                    Update Profile
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- Change Password Section -->
                    <div class="food-card" style="margin-top: 2rem;">
                        <div class="food-card-body" style="padding: 2rem;">
                            <h3 style="margin-bottom: 1.5rem;">Change Password</h3>

                            <form id="passwordForm">
                                <div class="form-group">
                                    <label for="current_password">Current Password *</label>
                                    <input type="password" 
                                           id="current_password" 
                                           name="current_password" 
                                           class="form-control" 
                                           required>
                                </div>

                                <div class="form-group">
                                    <label for="new_password">New Password *</label>
                                    <input type="password" 
                                           id="new_password" 
                                           name="new_password" 
                                           class="form-control" 
                                           minlength="6"
                                           required>
                                </div>

                                <div class="form-group">
                                    <label for="confirm_password">Confirm New Password *</label>
                                    <input type="password" 
                                           id="confirm_password" 
                                           name="confirm_password" 
                                           class="form-control" 
                                           minlength="6"
                                           required>
                                </div>

                                <button type="submit" class="btn btn-secondary btn-ripple">
                                    Change Password
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- Account Information -->
                    <div class="food-card" style="margin-top: 2rem;">
                        <div class="food-card-body" style="padding: 2rem;">
                            <h3 style="margin-bottom: 1.5rem;">Account Information</h3>
                            
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                                <div>
                                    <p style="color: #666; margin-bottom: 0.3rem;">Account Type</p>
                                    <strong><?php echo ucfirst($user['user_type']); ?></strong>
                                </div>
                                <div>
                                    <p style="color: #666; margin-bottom: 0.3rem;">Member Since</p>
                                    <strong><?php echo formatDate($user['created_at']); ?></strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include '../includes/footer.php'; ?>

    <script src="../js/main.js"></script>
    <script>
        // Password change form handler
        document.getElementById('passwordForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (newPassword !== confirmPassword) {
                showNotification('Passwords do not match!', 'error');
                return;
            }
            
            showLoading();
            
            const formData = new FormData(this);
            
            fetch('../actions/change-password.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                hideLoading();
                if (data.success) {
                    showNotification('Password changed successfully!', 'success');
                    this.reset();
                } else {
                    showNotification(data.message || 'Failed to change password', 'error');
                }
            })
            .catch(error => {
                hideLoading();
                showNotification('An error occurred', 'error');
            });
        });
    </script>
</body>
</html>