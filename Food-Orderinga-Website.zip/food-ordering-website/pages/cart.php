<?php
require_once '../config.php';
require_once '../functions.php';

$cart_items = [];
$total = 0;

if (!empty($_SESSION['cart'])) {
    $food_ids = array_keys($_SESSION['cart']);
    $ids_string = implode(',', $food_ids);
    
    $sql = "SELECT * FROM food_items WHERE food_id IN ($ids_string) AND active = 'YES'";
    $result = mysqli_query($conn, $sql);
    
    while ($food = mysqli_fetch_assoc($result)) {
        $food['quantity'] = $_SESSION['cart'][$food['food_id']];
        $food['subtotal'] = $food['price'] * $food['quantity'];
        $total += $food['subtotal'];
        $cart_items[] = $food;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="/food-ordering-website/css/style.css">
    <link rel="stylesheet" href="/food-ordering-website/css/animations.css">
    <link rel="stylesheet" href="/food-ordering-website/css/responsive.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <section class="py-3">
        <div class="container">
            <div class="section-title">
                <h2>Shopping Cart</h2>
                <p>Review your order before checkout</p>
            </div>

            <?php if (!empty($cart_items)): ?>
                <div style="display: grid; grid-template-columns: 1fr 350px; gap: 2rem; margin-top: 2rem;">
                    <!-- Cart Items -->
                    <div>
                        <?php foreach ($cart_items as $item): ?>
                            <div id="cart-item-<?php echo $item['food_id']; ?>" 
                                 class="food-card animate-fade-in" 
                                 style="display: flex; align-items: center; gap: 1.5rem; margin-bottom: 1.5rem;">
                                <img src="../images/foods/<?php echo $item['image_name'] ?: 'default-food.jpg'; ?>" 
                                     alt="<?php echo htmlspecialchars($item['food_name']); ?>"
                                     style="width: 120px; height: 120px; object-fit: cover; border-radius: 10px;">
                                
                                <div style="flex: 1;">
                                    <h3 style="margin-bottom: 0.5rem;"><?php echo htmlspecialchars($item['food_name']); ?></h3>
                                    <p style="color: #666; margin-bottom: 1rem;"><?php echo formatPrice($item['price']); ?> each</p>
                                    
                                    <div style="display: flex; align-items: center; gap: 1rem;">
                                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                                            <button class="btn quantity-minus" 
                                                    onclick="updateCartQuantity(<?php echo $item['food_id']; ?>, <?php echo $item['quantity'] - 1; ?>)"
                                                    style="padding: 0.5rem 1rem;">-</button>
                                            <input type="number" 
                                                   class="form-control cart-quantity-input" 
                                                   data-food-id="<?php echo $item['food_id']; ?>"
                                                   value="<?php echo $item['quantity']; ?>" 
                                                   min="1" max="99"
                                                   style="width: 80px; text-align: center;">
                                            <button class="btn quantity-plus" 
                                                    onclick="updateCartQuantity(<?php echo $item['food_id']; ?>, <?php echo $item['quantity'] + 1; ?>)"
                                                    style="padding: 0.5rem 1rem;">+</button>
                                        </div>
                                        
                                        <div style="margin-left: auto;">
                                            <strong id="subtotal-<?php echo $item['food_id']; ?>" 
                                                    style="font-size: 1.3rem; color: var(--primary-color);">
                                                <?php echo formatPrice($item['subtotal']); ?>
                                            </strong>
                                        </div>
                                    </div>
                                </div>

                                <button class="btn btn-danger remove-cart-item" 
                                        data-food-id="<?php echo $item['food_id']; ?>"
                                        style="padding: 0.5rem 1rem;">
                                    ✕
                                </button>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Order Summary -->
                    <div>
                        <div class="food-card" style="position: sticky; top: 100px;">
                            <div class="food-card-body">
                                <h3 style="margin-bottom: 1.5rem;">Order Summary</h3>
                                
                                <div style="border-top: 2px solid #eee; padding-top: 1rem;">
                                    <div style="display: flex; justify-content: space-between; margin-bottom: 1rem;">
                                        <span>Subtotal:</span>
                                        <span id="cart-total"><?php echo formatPrice($total); ?></span>
                                    </div>
                                    <div style="display: flex; justify-content: space-between; margin-bottom: 1rem;">
                                        <span>Delivery Fee:</span>
                                        <span><?php echo formatPrice(30); ?></span>
                                    </div>
                                    <div style="display: flex; justify-content: space-between; font-size: 1.3rem; font-weight: bold; border-top: 2px solid #eee; padding-top: 1rem; color: var(--primary-color);">
                                        <span>Total:</span>
                                        <span><?php echo formatPrice($total + 30); ?></span>
                                    </div>
                                </div>

                                <a href="checkout.php" class="btn btn-primary" style="width: 100%; margin-top: 1.5rem; text-align: center;">
                                    Proceed to Checkout
                                </a>
                                
                                <a href="menu.php" class="btn btn-secondary" style="width: 100%; margin-top: 0.5rem; text-align: center;">
                                    Continue Shopping
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

            <?php else: ?>
                <div class="text-center py-3 animate-fade-in">
                    <div style="font-size: 6rem; margin-bottom: 1rem;">🛒</div>
                    <h3>Your cart is empty</h3>
                    <p>Add some delicious items to get started!</p>
                    <a href="menu.php" class="btn btn-primary mt-2">Browse Menu</a>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <?php include '../includes/footer.php'; ?>

    <script src="/food-ordering-website/js/main.js"></script>
    <script src="/food-ordering-website/js/cart.js"></script>
</body>
</html>