<?php
require_once '../config.php';
require_once '../functions.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="/food-ordering-website/css/style.css">
    <link rel="stylesheet" href="/food-ordering-website/css/animations.css">
    <link rel="stylesheet" href="/food-ordering-website/css/responsive.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <!-- Hero Section -->
    <section style="background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: white; padding: 5rem 0; text-align: center;">
        <div class="container">
            <h1 class="animate-fade-in" style="font-size: 3rem; margin-bottom: 1rem;">About <?php echo SITE_NAME; ?></h1>
            <p class="animate-fade-in" style="font-size: 1.3rem;">Your trusted partner for delicious food delivery</p>
        </div>
    </section>

    <!-- Our Story -->
    <section class="py-3">
        <div class="container">
            <div class="section-title">
                <h2>Our Story</h2>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 3rem; align-items: center;">
                <div class="animate-slide-left">
                    <p style="font-size: 1.1rem; line-height: 1.8; color: #666; margin-bottom: 1rem;">
                        Founded in 2024, <?php echo SITE_NAME; ?> started with a simple mission: to bring delicious, quality food to your doorstep. We understand that great food brings people together, and we're passionate about making that experience as convenient and enjoyable as possible.
                    </p>
                    <p style="font-size: 1.1rem; line-height: 1.8; color: #666; margin-bottom: 1rem;">
                        Our platform connects you with the best restaurants in your area, offering a wide variety of cuisines to satisfy every craving. From traditional favorites to exciting new flavors, we've got something for everyone.
                    </p>
                    <p style="font-size: 1.1rem; line-height: 1.8; color: #666;">
                        We're committed to providing exceptional service, ensuring your food arrives fresh, hot, and on time, every time.
                    </p>
                </div>
                <div class="animate-slide-right">
                    <div style="background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); height: 400px; border-radius: 20px; display: flex; align-items: center; justify-content: center; color: white; font-size: 5rem;">
                        🍕
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Our Values -->
    <section class="py-3" style="background: var(--light-color);">
        <div class="container">
            <div class="section-title">
                <h2>Our Values</h2>
                <p>What makes us different</p>
            </div>

            <div class="food-grid">
                <div class="food-card text-center animate-fade-in">
                    <div class="food-card-body">
                        <div style="font-size: 4rem; margin-bottom: 1rem;">⚡</div>
                        <h3>Speed</h3>
                        <p>We value your time. Our efficient delivery system ensures your food arrives quickly while maintaining quality.</p>
                    </div>
                </div>

                <div class="food-card text-center animate-fade-in">
                    <div class="food-card-body">
                        <div style="font-size: 4rem; margin-bottom: 1rem;">🎯</div>
                        <h3>Quality</h3>
                        <p>We partner only with restaurants that meet our high standards for food quality and hygiene.</p>
                    </div>
                </div>

                <div class="food-card text-center animate-fade-in">
                    <div class="food-card-body">
                        <div style="font-size: 4rem; margin-bottom: 1rem;">💝</div>
                        <h3>Customer First</h3>
                        <p>Your satisfaction is our priority. We're always here to ensure you have the best experience.</p>
                    </div>
                </div>

                <div class="food-card text-center animate-fade-in">
                    <div class="food-card-body">
                        <div style="font-size: 4rem; margin-bottom: 1rem;">🌟</div>
                        <h3>Innovation</h3>
                        <p>We continuously improve our platform and services to give you the best food ordering experience.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Statistics -->
    <section class="py-3">
        <div class="container">
            <div class="food-grid">
                <div class="food-card text-center">
                    <div class="food-card-body">
                        <h2 style="color: var(--primary-color); font-size: 3rem; margin-bottom: 0.5rem;">50+</h2>
                        <p style="font-size: 1.2rem; color: #666;">Partner Restaurants</p>
                    </div>
                </div>

                <div class="food-card text-center">
                    <div class="food-card-body">
                        <h2 style="color: var(--secondary-color); font-size: 3rem; margin-bottom: 0.5rem;">10,000+</h2>
                        <p style="font-size: 1.2rem; color: #666;">Happy Customers</p>
                    </div>
                </div>

                <div class="food-card text-center">
                    <div class="food-card-body">
                        <h2 style="color: var(--success-color); font-size: 3rem; margin-bottom: 0.5rem;">30 Min</h2>
                        <p style="font-size: 1.2rem; color: #666;">Average Delivery Time</p>
                    </div>
                </div>

                <div class="food-card text-center">
                    <div class="food-card-body">
                        <h2 style="color: var(--warning-color); font-size: 3rem; margin-bottom: 0.5rem;">4.8★</h2>
                        <p style="font-size: 1.2rem; color: #666;">Average Rating</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Call to Action -->
    <section class="py-3" style="background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: white; text-align: center;">
        <div class="container">
            <h2 style="font-size: 2.5rem; margin-bottom: 1rem;">Ready to Order?</h2>
            <p style="font-size: 1.2rem; margin-bottom: 2rem;">Join thousands of satisfied customers and enjoy delicious food delivered to your door</p>
            <a href="menu.php" class="btn" style="background: white; color: var(--primary-color);">Browse Menu</a>
        </div>
    </section>

    <?php include '../includes/footer.php'; ?>

    <script src="/food-ordering-website/js/main.js"></script>
</body>
</html>