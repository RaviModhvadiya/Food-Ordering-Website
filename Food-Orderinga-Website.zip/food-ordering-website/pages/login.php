<?php
require_once '../config.php';
require_once '../functions.php';

// Redirect if already logged in
if (isLoggedIn()) {
    redirect('pages/profile.php');
}

$error = '';
$success = '';

if (isset($_SESSION['success_message'])) {
    $success = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}

if (isset($_SESSION['error_message'])) {
    $error = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/animations.css">
    <link rel="stylesheet" href="../css/responsive.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <section class="py-3">
        <div class="container">
            <div style="max-width: 500px; margin: 0 auto;">
                <div class="food-card animate-scale">
                    <div class="food-card-body" style="padding: 3rem;">
                        <h2 class="text-center" style="margin-bottom: 2rem;">Login to Your Account</h2>

                        <?php if ($error): ?>
                            <?php echo showError($error); ?>
                        <?php endif; ?>

                        <?php if ($success): ?>
                            <?php echo showSuccess($success); ?>
                        <?php endif; ?>

                        <form action="../actions/user-login.php" method="POST">
                            <div class="form-group">
                                <label for="email">Email Address *</label>
                                <input type="email" 
                                       id="email" 
                                       name="email" 
                                       class="form-control" 
                                       required 
                                       placeholder="Enter your email">
                            </div>

                            <div class="form-group">
                                <label for="password">Password *</label>
                                <input type="password" 
                                       id="password" 
                                       name="password" 
                                       class="form-control" 
                                       required 
                                       placeholder="Enter your password">
                            </div>

                            <div class="form-group" style="display: flex; justify-content: space-between; align-items: center;">
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" name="remember_me">
                                    <span>Remember Me</span>
                                </label>
                                <a href="#" style="color: var(--primary-color); text-decoration: none;">Forgot Password?</a>
                            </div>

                            <button type="submit" class="btn btn-primary btn-ripple" style="width: 100%;">
                                Login
                            </button>

                            <p class="text-center mt-2">
                                Don't have an account? 
                                <a href="register.php" style="color: var(--primary-color); font-weight: bold;">Register Here</a>
                            </p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include '../includes/footer.php'; ?>

    <script src="../js/main.js"></script>
</body>
</html>