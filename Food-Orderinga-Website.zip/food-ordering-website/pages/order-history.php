<?php
require_once '../config.php';
require_once '../functions.php';

if (!isLoggedIn()) {
    redirect('pages/login.php');
}

$user_id = $_SESSION['user_id'];

// Get user orders
$sql = "SELECT * FROM orders WHERE user_id = $user_id ORDER BY order_date DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/animations.css">
    <link rel="stylesheet" href="../css/responsive.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <section class="py-3">
        <div class="container">
            <div class="section-title">
                <h2>Order History</h2>
                <p>View your past orders</p>
            </div>

            <?php if (mysqli_num_rows($result) > 0): ?>
                <div style="max-width: 1000px; margin: 0 auto;">
                    <?php while ($order = mysqli_fetch_assoc($result)): ?>
                        <div class="food-card animate-fade-in" style="margin-bottom: 2rem;">
                            <div class="food-card-body" style="padding: 2rem;">
                                <!-- Order Header -->
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; padding-bottom: 1rem; border-bottom: 2px solid #eee;">
                                    <div>
                                        <h3>Order #<?php echo $order['order_id']; ?></h3>
                                        <p style="color: #666; margin-top: 0.5rem;">
                                            Placed on <?php echo formatDate($order['order_date']); ?>
                                        </p>
                                    </div>
                                    <div style="text-align: right;">
                                        <?php
                                        $status_class = '';
                                        switch ($order['order_status']) {
                                            case 'Ordered':
                                                $status_class = 'badge-primary';
                                                break;
                                            case 'Processing':
                                                $status_class = 'badge-warning';
                                                break;
                                            case 'Delivered':
                                                $status_class = 'badge-success';
                                                break;
                                            case 'Cancelled':
                                                $status_class = 'badge-danger';
                                                break;
                                        }
                                        ?>
                                        <span class="badge <?php echo $status_class; ?>" style="font-size: 1rem;">
                                            <?php echo $order['order_status']; ?>
                                        </span>
                                        <p style="font-size: 1.3rem; font-weight: bold; color: var(--primary-color); margin-top: 0.5rem;">
                                            <?php echo formatPrice($order['total_amount']); ?>
                                        </p>
                                    </div>
                                </div>

                                <!-- Order Items -->
                                <?php
                                $order_id = $order['order_id'];
                                $sql_items = "SELECT oi.*, f.food_name, f.image_name 
                                             FROM order_items oi 
                                             JOIN food_items f ON oi.food_id = f.food_id 
                                             WHERE oi.order_id = $order_id";
                                $result_items = mysqli_query($conn, $sql_items);
                                ?>

                                <div style="display: grid; gap: 1rem;">
                                    <?php while ($item = mysqli_fetch_assoc($result_items)): ?>
                                        <div style="display: flex; align-items: center; gap: 1rem; padding: 1rem; background: #f8f9fa; border-radius: 10px;">
                                            <img src="../images/foods/<?php echo $item['image_name'] ?: 'default-food.jpg'; ?>" 
                                                 alt="<?php echo htmlspecialchars($item['food_name']); ?>"
                                                 style="width: 60px; height: 60px; object-fit: cover; border-radius: 8px;">
                                            <div style="flex: 1;">
                                                <strong><?php echo htmlspecialchars($item['food_name']); ?></strong>
                                                <p style="color: #666; margin-top: 0.3rem; font-size: 0.9rem;">
                                                    Qty: <?php echo $item['quantity']; ?> × <?php echo formatPrice($item['price']); ?>
                                                </p>
                                            </div>
                                            <strong style="color: var(--primary-color);">
                                                <?php echo formatPrice($item['subtotal']); ?>
                                            </strong>
                                        </div>
                                    <?php endwhile; ?>
                                </div>

                                <!-- Order Details -->
                                <div style="margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid #eee;">
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                                        <div>
                                            <p><strong>Payment:</strong> <?php echo htmlspecialchars($order['payment_method']); ?></p>
                                            <p><strong>Contact:</strong> <?php echo htmlspecialchars($order['contact_phone']); ?></p>
                                        </div>
                                        <div>
                                            <p><strong>Delivery Address:</strong></p>
                                            <p style="color: #666;"><?php echo htmlspecialchars($order['delivery_address']); ?></p>
                                        </div>
                                    </div>
                                </div>

                                <!-- Action Buttons -->
                                <?php if ($order['order_status'] === 'Delivered'): ?>
                                    <div style="margin-top: 1.5rem; text-align: right;">
                                        <button class="btn btn-primary" onclick="showNotification('Reorder functionality coming soon!', 'success')">
                                            Reorder
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>

            <?php else: ?>
                <div class="text-center py-3 animate-fade-in">
                    <div style="font-size: 6rem; margin-bottom: 1rem;">📦</div>
                    <h3>No orders yet</h3>
                    <p>Start ordering delicious food today!</p>
                    <a href="menu.php" class="btn btn-primary mt-2">Browse Menu</a>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <?php include '../includes/footer.php'; ?>

    <script src="../js/main.js"></script>
</body>
</html>