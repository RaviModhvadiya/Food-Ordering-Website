<?php
require_once '../config.php';

// Define functions if not loaded
if (!function_exists('isLoggedIn')) {
    function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }
}

if (!function_exists('formatPrice')) {
    function formatPrice($price) {
        return '₹' . number_format($price, 2);
    }
}

if (!function_exists('getCartTotal')) {
    function getCartTotal() {
        global $conn;
        $total = 0;
        if (!empty($_SESSION['cart'])) {
            foreach ($_SESSION['cart'] as $food_id => $quantity) {
                $sql = "SELECT price FROM food_items WHERE food_id = " . (int)$food_id;
                $result = mysqli_query($conn, $sql);
                if ($row = mysqli_fetch_assoc($result)) {
                    $total += $row['price'] * $quantity;
                }
            }
        }
        return $total;
    }
}

if (!function_exists('getCartCount')) {
    function getCartCount() {
        $count = 0;
        if (!empty($_SESSION['cart'])) {
            foreach ($_SESSION['cart'] as $quantity) {
                $count += $quantity;
            }
        }
        return $count;
    }
}

// Check if user is logged in
if (!isLoggedIn()) {
    // Store the intended destination
    $_SESSION['redirect_after_login'] = 'pages/checkout.php';
    $_SESSION['error_message'] = 'Please login to continue with checkout';
    header("Location: " . SITE_URL . "pages/login.php");
    exit();
}

// Check if cart is empty
if (empty($_SESSION['cart']) || getCartCount() == 0) {
    $_SESSION['error_message'] = 'Your cart is empty. Please add items to cart.';
    header("Location: " . SITE_URL . "pages/foods.php");
    exit();
}

// Get user details
$user_id = $_SESSION['user_id'];
$sql_user = "SELECT * FROM users WHERE user_id = $user_id";
$result_user = mysqli_query($conn, $sql_user);
$user = mysqli_fetch_assoc($result_user);

// Get cart items
$cart_items = [];
$subtotal = 0;

if (!empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $food_id => $quantity) {
        $sql = "SELECT * FROM food_items WHERE food_id = " . (int)$food_id;
        $result = mysqli_query($conn, $sql);
        if ($row = mysqli_fetch_assoc($result)) {
            $row['quantity'] = $quantity;
            $row['item_total'] = $row['price'] * $quantity;
            $subtotal += $row['item_total'];
            $cart_items[] = $row;
        }
    }
}

$delivery_fee = 30.00;
$total = $subtotal + $delivery_fee;

// Handle order placement
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    $delivery_address = mysqli_real_escape_string($conn, trim($_POST['delivery_address']));
    $contact_phone = mysqli_real_escape_string($conn, trim($_POST['contact_phone']));
    $payment_method = mysqli_real_escape_string($conn, $_POST['payment_method']);
    
    if (empty($delivery_address) || empty($contact_phone)) {
        $error = 'Please fill in all required fields';
    } else {
        // Insert order
        $sql_order = "INSERT INTO orders (user_id, total_amount, payment_method, delivery_address, contact_phone, order_status, order_date) 
                      VALUES ($user_id, $total, '$payment_method', '$delivery_address', '$contact_phone', 'Ordered', NOW())";
        
        if (mysqli_query($conn, $sql_order)) {
            $order_id = mysqli_insert_id($conn);
            
            // Insert order items
            foreach ($cart_items as $item) {
                $food_id = $item['food_id'];
                $quantity = $item['quantity'];
                $price = $item['price'];
                $subtotal_item = $item['item_total'];
                
                $sql_item = "INSERT INTO order_items (order_id, food_id, quantity, price, subtotal) 
                            VALUES ($order_id, $food_id, $quantity, $price, $subtotal_item)";
                mysqli_query($conn, $sql_item);
            }
            
            // Clear cart
            $_SESSION['cart'] = [];
            
            // Redirect to success page
            $_SESSION['success_message'] = 'Order placed successfully! Order ID: #' . $order_id;
            header("Location: " . SITE_URL . "pages/order-success.php?order_id=" . $order_id);
            exit();
        } else {
            $error = 'Failed to place order. Please try again.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - <?php echo SITE_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .header {
            background: white;
            padding: 20px 30px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            color: #2c3e50;
            font-size: 28px;
        }

        .back-btn {
            padding: 10px 25px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            text-decoration: none;
            border-radius: 10px;
            font-weight: 600;
            transition: transform 0.3s ease;
        }

        .back-btn:hover {
            transform: translateY(-2px);
        }

        .checkout-grid {
            display: grid;
            grid-template-columns: 1fr 400px;
            gap: 30px;
        }

        .card {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .card h2 {
            color: #2c3e50;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #ecf0f1;
            font-size: 24px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            color: #2c3e50;
            font-weight: 600;
        }

        .form-control {
            width: 100%;
            padding: 15px;
            border: 2px solid #e1e8ed;
            border-radius: 10px;
            font-size: 16px;
            font-family: 'Poppins', sans-serif;
            transition: border-color 0.3s ease;
        }

        .form-control:focus {
            outline: none;
            border-color: #667eea;
        }

        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }

        .payment-methods {
            display: grid;
            gap: 15px;
        }

        .payment-option {
            display: flex;
            align-items: center;
            padding: 15px;
            border: 2px solid #e1e8ed;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .payment-option:hover {
            border-color: #667eea;
            background: #f8f9fa;
        }

        .payment-option input[type="radio"] {
            width: 20px;
            height: 20px;
            margin-right: 15px;
            cursor: pointer;
            accent-color: #667eea;
        }

        .payment-option label {
            cursor: pointer;
            font-weight: 500;
            margin: 0;
        }

        .cart-item {
            display: flex;
            gap: 15px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
            margin-bottom: 15px;
        }

        .cart-item img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 10px;
        }

        .item-details {
            flex: 1;
        }

        .item-name {
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 5px;
        }

        .item-price {
            color: #667eea;
            font-weight: 600;
        }

        .item-quantity {
            color: #7f8c8d;
            font-size: 14px;
        }

        .order-summary {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 15px;
            margin-top: 20px;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
            color: #2c3e50;
        }

        .summary-row.total {
            font-size: 20px;
            font-weight: 700;
            color: #667eea;
            padding-top: 15px;
            border-top: 2px solid #dee2e6;
        }

        .btn-place-order {
            width: 100%;
            padding: 18px;
            background: linear-gradient(135deg, #2ecc71, #27ae60);
            color: white;
            border: none;
            border-radius: 15px;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-top: 20px;
        }

        .btn-place-order:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(46, 204, 113, 0.3);
        }

        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-error {
            background: #fee;
            color: #c00;
            border: 2px solid #fcc;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 2px solid #c3e6cb;
        }

        @media (max-width: 968px) {
            .checkout-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🛒 Checkout</h1>
            <a href="../pages/cart.php" class="back-btn">← Back to Cart</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error">
                <span style="font-size: 20px;">⚠️</span>
                <span><?php echo htmlspecialchars($error); ?></span>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="checkout-grid">
                <!-- Left Column - Delivery Details -->
                <div>
                    <div class="card">
                        <h2>📍 Delivery Information</h2>

                        <div class="form-group">
                            <label for="full_name">Full Name</label>
                            <input type="text" 
                                   id="full_name" 
                                   class="form-control" 
                                   value="<?php echo htmlspecialchars($user['full_name']); ?>" 
                                   readonly>
                        </div>

                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" 
                                   id="email" 
                                   class="form-control" 
                                   value="<?php echo htmlspecialchars($user['email']); ?>" 
                                   readonly>
                        </div>

                        <div class="form-group">
                            <label for="contact_phone">Contact Phone *</label>
                            <input type="tel" 
                                   id="contact_phone" 
                                   name="contact_phone" 
                                   class="form-control" 
                                   placeholder="Enter your phone number"
                                   value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>"
                                   required>
                        </div>

                        <div class="form-group">
                            <label for="delivery_address">Delivery Address *</label>
                            <textarea id="delivery_address" 
                                      name="delivery_address" 
                                      class="form-control" 
                                      placeholder="Enter complete delivery address with landmark"
                                      required><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                        </div>
                    </div>

                    <div class="card" style="margin-top: 30px;">
                        <h2>💳 Payment Method</h2>
                        <div class="payment-methods">
                            <div class="payment-option">
                                <input type="radio" id="cod" name="payment_method" value="Cash on Delivery" checked>
                                <label for="cod">
                                    <strong>Cash on Delivery</strong><br>
                                    <small style="color: #7f8c8d;">Pay when you receive your order</small>
                                </label>
                            </div>

                            <div class="payment-option">
                                <input type="radio" id="upi" name="payment_method" value="UPI">
                                <label for="upi">
                                    <strong>UPI Payment</strong><br>
                                    <small style="color: #7f8c8d;">Pay via PhonePe, Google Pay, Paytm</small>
                                </label>
                            </div>

                            <div class="payment-option">
                                <input type="radio" id="card" name="payment_method" value="Credit/Debit Card">
                                <label for="card">
                                    <strong>Credit/Debit Card</strong><br>
                                    <small style="color: #7f8c8d;">Pay securely with your card</small>
                                </label>
                            </div>

                            <div class="payment-option">
                                <input type="radio" id="netbanking" name="payment_method" value="Net Banking">
                                <label for="netbanking">
                                    <strong>Net Banking</strong><br>
                                    <small style="color: #7f8c8d;">Direct bank transfer</small>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Right Column - Order Summary -->
                <div>
                    <div class="card">
                        <h2>📦 Order Summary</h2>

                        <?php foreach ($cart_items as $item): ?>
                            <div class="cart-item">
                                <img src="../images/foods/<?php echo $item['image_name'] ?: 'default-food.jpg'; ?>" 
                                     alt="<?php echo htmlspecialchars($item['food_name']); ?>">
                                <div class="item-details">
                                    <div class="item-name"><?php echo htmlspecialchars($item['food_name']); ?></div>
                                    <div class="item-quantity">Quantity: <?php echo $item['quantity']; ?></div>
                                    <div class="item-price"><?php echo formatPrice($item['item_total']); ?></div>
                                </div>
                            </div>
                        <?php endforeach; ?>

                        <div class="order-summary">
                            <div class="summary-row">
                                <span>Subtotal (<?php echo getCartCount(); ?> items):</span>
                                <strong><?php echo formatPrice($subtotal); ?></strong>
                            </div>
                            <div class="summary-row">
                                <span>Delivery Fee:</span>
                                <strong><?php echo formatPrice($delivery_fee); ?></strong>
                            </div>
                            <div class="summary-row total">
                                <span>Total Amount:</span>
                                <span><?php echo formatPrice($total); ?></span>
                            </div>
                        </div>

                        <button type="submit" name="place_order" class="btn-place-order">
                            🎉 Place Order - <?php echo formatPrice($total); ?>
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</body>
</html>