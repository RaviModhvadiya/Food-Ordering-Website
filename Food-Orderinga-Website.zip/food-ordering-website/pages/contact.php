<?php
require_once '../config.php';
require_once '../functions.php';

$success = '';
$error = '';

if (isset($_SESSION['success_message'])) {
    $success = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}

if (isset($_SESSION['error_message'])) {
    $error = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="/food-ordering-website/css/style.css">
    <link rel="stylesheet" href="/food-ordering-website/css/animations.css">
    <link rel="stylesheet" href="/food-ordering-website/css/responsive.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <section class="py-3">
        <div class="container">
            <div class="section-title">
                <h2>Contact Us</h2>
                <p>We'd love to hear from you</p>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 3rem; margin-top: 3rem;">
                <!-- Contact Form -->
                <div class="food-card animate-slide-left">
                    <div class="food-card-body" style="padding: 2rem;">
                        <h3 style="margin-bottom: 1.5rem;">Send us a Message</h3>

                        <?php if ($success): ?>
                            <?php echo showSuccess($success); ?>
                        <?php endif; ?>

                        <?php if ($error): ?>
                            <?php echo showError($error); ?>
                        <?php endif; ?>

                        <form action="/food-ordering-website/actions/contact-submit.php" method="POST">
                            <div class="form-group">
                                <label for="name">Your Name *</label>
                                <input type="text" 
                                       id="name" 
                                       name="name" 
                                       class="form-control" 
                                       required 
                                       placeholder="Enter your name">
                            </div>

                            <div class="form-group">
                                <label for="email">Email Address *</label>
                                <input type="email" 
                                       id="email" 
                                       name="email" 
                                       class="form-control" 
                                       required 
                                       placeholder="Enter your email">
                            </div>

                            <div class="form-group">
                                <label for="subject">Subject *</label>
                                <input type="text" 
                                       id="subject" 
                                       name="subject" 
                                       class="form-control" 
                                       required 
                                       placeholder="What is your inquiry about?">
                            </div>

                            <div class="form-group">
                                <label for="message">Message *</label>
                                <textarea id="message" 
                                          name="message" 
                                          class="form-control" 
                                          required 
                                          rows="6"
                                          placeholder="Write your message here..."></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary btn-ripple" style="width: 100%;">
                                Send Message
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Contact Information -->
                <div class="animate-slide-right">
                    <div class="food-card" style="margin-bottom: 2rem;">
                        <div class="food-card-body" style="padding: 2rem;">
                            <h3 style="margin-bottom: 1.5rem;">Contact Information</h3>
                            
                            <div style="display: flex; align-items: start; gap: 1rem; margin-bottom: 1.5rem;">
                                <div style="font-size: 2rem;">📍</div>
                                <div>
                                    <strong>Address</strong>
                                    <p style="color: #666; margin-top: 0.3rem;">
                                        123 Food Street<br>
                                        Rajkot, Gujarat, India
                                    </p>
                                </div>
                            </div>

                            <div style="display: flex; align-items: start; gap: 1rem; margin-bottom: 1.5rem;">
                                <div style="font-size: 2rem;">📞</div>
                                <div>
                                    <strong>Phone</strong>
                                    <p style="color: #666; margin-top: 0.3rem;">
                                        +91 1234567890<br>
                                        +91 9876543210
                                    </p>
                                </div>
                            </div>

                            <div style="display: flex; align-items: start; gap: 1rem; margin-bottom: 1.5rem;">
                                <div style="font-size: 2rem;">📧</div>
                                <div>
                                    <strong>Email</strong>
                                    <p style="color: #666; margin-top: 0.3rem;">
                                        info@foodorder.com<br>
                                        support@foodorder.com
                                    </p>
                                </div>
                            </div>

                            <div style="display: flex; align-items: start; gap: 1rem;">
                                <div style="font-size: 2rem;">⏰</div>
                                <div>
                                    <strong>Working Hours</strong>
                                    <p style="color: #666; margin-top: 0.3rem;">
                                        Monday - Sunday<br>
                                        9:00 AM - 11:00 PM
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="food-card">
                        <div class="food-card-body" style="padding: 2rem;">
                            <h3 style="margin-bottom: 1.5rem;">Follow Us</h3>
                            <div style="display: flex; gap: 1rem;">
                                <a href="#" class="btn btn-primary" style="flex: 1; text-align: center;">Facebook</a>
                                <a href="#" class="btn btn-primary" style="flex: 1; text-align: center;">Instagram</a>
                            </div>
                            <div style="display: flex; gap: 1rem; margin-top: 1rem;">
                                <a href="#" class="btn btn-secondary" style="flex: 1; text-align: center;">Twitter</a>
                                <a href="#" class="btn btn-secondary" style="flex: 1; text-align: center;">YouTube</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include '../includes/footer.php'; ?>

    <script src="/food-ordering-website/js/main.js"></script>
</body>
</html>