<?php
require_once '../config.php';
require_once '../functions.php';

// Redirect if already logged in
if (isLoggedIn()) {
    redirect('pages/profile.php');
}

$error = '';
if (isset($_SESSION['error_message'])) {
    $error = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/animations.css">
    <link rel="stylesheet" href="../css/responsive.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <section class="py-3">
        <div class="container">
            <div style="max-width: 600px; margin: 0 auto;">
                <div class="food-card animate-scale">
                    <div class="food-card-body" style="padding: 3rem;">
                        <h2 class="text-center" style="margin-bottom: 2rem;">Create New Account</h2>

                        <?php if ($error): ?>
                            <?php echo showError($error); ?>
                        <?php endif; ?>

                        <form action="../actions/user-register.php" method="POST">
                            <div class="form-group">
                                <label for="full_name">Full Name *</label>
                                <input type="text" 
                                       id="full_name" 
                                       name="full_name" 
                                       class="form-control" 
                                       required 
                                       placeholder="Enter your full name">
                            </div>

                            <div class="form-group">
                                <label for="email">Email Address *</label>
                                <input type="email" 
                                       id="email" 
                                       name="email" 
                                       class="form-control" 
                                       required 
                                       placeholder="Enter your email">
                            </div>

                            <div class="form-group">
                                <label for="phone">Phone Number *</label>
                                <input type="tel" 
                                       id="phone" 
                                       name="phone" 
                                       class="form-control" 
                                       required 
                                       placeholder="Enter your phone number">
                            </div>

                            <div class="form-group">
                                <label for="address">Delivery Address *</label>
                                <textarea id="address" 
                                          name="address" 
                                          class="form-control" 
                                          required 
                                          placeholder="Enter your complete address"></textarea>
                            </div>

                            <div class="form-group">
                                <label for="password">Password *</label>
                                <input type="password" 
                                       id="password" 
                                       name="password" 
                                       class="form-control" 
                                       required 
                                       minlength="6"
                                       placeholder="Enter password (min 6 characters)">
                            </div>

                            <div class="form-group">
                                <label for="confirm_password">Confirm Password *</label>
                                <input type="password" 
                                       id="confirm_password" 
                                       name="confirm_password" 
                                       class="form-control" 
                                       required 
                                       placeholder="Confirm your password">
                            </div>

                            <div class="form-group">
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" required>
                                    <span>I agree to the Terms & Conditions</span>
                                </label>
                            </div>

                            <button type="submit" class="btn btn-primary btn-ripple" style="width: 100%;">
                                Register
                            </button>

                            <p class="text-center mt-2">
                                Already have an account? 
                                <a href="login.php" style="color: var(--primary-color); font-weight: bold;">Login Here</a>
                            </p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include '../includes/footer.php'; ?>

    <script src="../js/main.js"></script>
    <script>
        // Password match validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (password !== confirmPassword) {
                e.preventDefault();
                showNotification('Passwords do not match!', 'error');
                document.getElementById('confirm_password').focus();
            }
        });
    </script>
</body>
</html>