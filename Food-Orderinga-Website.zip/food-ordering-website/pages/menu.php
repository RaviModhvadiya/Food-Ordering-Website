<?php
require_once '../config.php';
require_once '../functions.php';

// Get all categories
$sql_categories = "SELECT * FROM categories WHERE active = 'YES'";
$result_categories = mysqli_query($conn, $sql_categories);

// Get selected category filter
$category_filter = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$search_query = isset($_GET['search']) ? sanitize($_GET['search']) : '';

// Build SQL query for food items
$sql_foods = "SELECT f.*, c.category_name 
              FROM food_items f 
              LEFT JOIN categories c ON f.category_id = c.category_id 
              WHERE f.active = 'YES'";

if ($category_filter > 0) {
    $sql_foods .= " AND f.category_id = $category_filter";
}

if (!empty($search_query)) {
    $sql_foods .= " AND (f.food_name LIKE '%$search_query%' OR f.description LIKE '%$search_query%')";
}

$sql_foods .= " ORDER BY f.food_name ASC";
$result_foods = mysqli_query($conn, $sql_foods);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/animations.css">
    <link rel="stylesheet" href="../css/responsive.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <section class="py-3">
        <div class="container">
            <div class="section-title">
                <h2>Our Menu</h2>
                <p>Explore our delicious food items</p>
            </div>

            <!-- Search and Filter -->
            <div style="background: white; padding: 2rem; border-radius: 15px; box-shadow: var(--shadow); margin-bottom: 3rem;">
                <form method="GET" action="" style="display: flex; gap: 1rem; flex-wrap: wrap; align-items: center;">
                    <div style="flex: 1; min-width: 250px;">
                        <input type="text" 
                               name="search" 
                               id="search-input"
                               class="form-control" 
                               placeholder="Search for food..." 
                               value="<?php echo htmlspecialchars($search_query); ?>">
                    </div>
                    
                    <div style="min-width: 200px;">
                        <select name="category" class="form-control">
                            <option value="0">All Categories</option>
                            <?php
                            mysqli_data_seek($result_categories, 0);
                            while ($cat = mysqli_fetch_assoc($result_categories)) {
                                $selected = ($category_filter == $cat['category_id']) ? 'selected' : '';
                                echo "<option value='{$cat['category_id']}' $selected>{$cat['category_name']}</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">Search</button>
                    
                    <?php if ($category_filter > 0 || !empty($search_query)): ?>
                        <a href="menu.php" class="btn btn-secondary">Clear Filters</a>
                    <?php endif; ?>
                </form>
            </div>

            <!-- Food Items Grid -->
            <?php if (mysqli_num_rows($result_foods) > 0): ?>
                <div class="food-grid">
                    <?php while ($food = mysqli_fetch_assoc($result_foods)): ?>
                        <div class="food-card hover-lift hover-zoom searchable-item">
                            <img src="/food-ordering-website/images/foods/<?php echo $food['image_name'] ?: 'default-food.jpg'; ?>" 
                                 alt="<?php echo htmlspecialchars($food['food_name']); ?>">
                            <div class="food-card-body">
                                <span class="badge badge-primary"><?php echo $food['category_name']; ?></span>
                                <h3><?php echo htmlspecialchars($food['food_name']); ?></h3>
                                <p><?php echo htmlspecialchars($food['description']); ?></p>
                                <div class="food-price"><?php echo formatPrice($food['price']); ?></div>
                                <button onclick="addToCart(<?php echo $food['food_id']; ?>, '<?php echo addslashes($food['food_name']); ?>', <?php echo $food['price']; ?>)" 
                                        class="btn btn-primary btn-ripple">
                                    Add to Cart
                                </button>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="text-center py-3">
                    <div style="font-size: 5rem; margin-bottom: 1rem;">😞</div>
                    <h3>No food items found</h3>
                    <p>Try adjusting your filters or search terms</p>
                    <a href="menu.php" class="btn btn-primary mt-2">View All Items</a>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <?php include '../includes/footer.php'; ?>

    <script src="../js/main.js"></script>
    <script src="../js/cart.js"></script>
</body>
</html>