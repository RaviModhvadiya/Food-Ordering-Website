<?php
require_once '../config.php';
require_once '../functions.php';

if (!isLoggedIn() || !isset($_GET['order_id'])) {
    redirect('');
}

$order_id = (int)$_GET['order_id'];
$user_id = $_SESSION['user_id'];

// Get order details
$sql = "SELECT o.*, u.full_name, u.email 
        FROM orders o 
        JOIN users u ON o.user_id = u.user_id 
        WHERE o.order_id = $order_id AND o.user_id = $user_id";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) === 0) {
    redirect('');
}

$order = mysqli_fetch_assoc($result);

// Get order items
$sql_items = "SELECT oi.*, f.food_name, f.image_name 
              FROM order_items oi 
              JOIN food_items f ON oi.food_id = f.food_id 
              WHERE oi.order_id = $order_id";
$result_items = mysqli_query($conn, $sql_items);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Success - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/animations.css">
    <link rel="stylesheet" href="../css/responsive.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <section class="py-3">
        <div class="container">
            <div style="max-width: 800px; margin: 0 auto;">
                <!-- Success Message -->
                <div class="text-center animate-scale" style="margin-bottom: 3rem;">
                    <div style="font-size: 5rem; color: var(--success-color); animation: bounce 1s;">✓</div>
                    <h1 style="color: var(--success-color); margin: 1rem 0;">Order Placed Successfully!</h1>
                    <p style="font-size: 1.2rem; color: #666;">Thank you for your order. Your food will be delivered soon.</p>
                </div>

                <!-- Order Details -->
                <div class="food-card animate-fade-in">
                    <div class="food-card-body" style="padding: 2rem;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; padding-bottom: 1rem; border-bottom: 2px solid #eee;">
                            <div>
                                <h3>Order #<?php echo $order_id; ?></h3>
                                <p style="color: #666; margin-top: 0.5rem;">
                                    Placed on <?php echo formatDate($order['order_date']); ?>
                                </p>
                            </div>
                            <span class="badge badge-success"><?php echo $order['order_status']; ?></span>
                        </div>

                        <!-- Order Items -->
                        <h4 style="margin-bottom: 1rem;">Order Items</h4>
                        <div style="margin-bottom: 2rem;">
                            <?php while ($item = mysqli_fetch_assoc($result_items)): ?>
                                <div style="display: flex; align-items: center; gap: 1rem; padding: 1rem; background: #f8f9fa; border-radius: 10px; margin-bottom: 1rem;">
                                    <img src="../images/foods/<?php echo $item['image_name'] ?: 'default-food.jpg'; ?>" 
                                         alt="<?php echo htmlspecialchars($item['food_name']); ?>"
                                         style="width: 80px; height: 80px; object-fit: cover; border-radius: 8px;">
                                    <div style="flex: 1;">
                                        <strong><?php echo htmlspecialchars($item['food_name']); ?></strong>
                                        <p style="color: #666; margin-top: 0.3rem;">
                                            Quantity: <?php echo $item['quantity']; ?> × <?php echo formatPrice($item['price']); ?>
                                        </p>
                                    </div>
                                    <strong style="color: var(--primary-color);">
                                        <?php echo formatPrice($item['subtotal']); ?>
                                    </strong>
                                </div>
                            <?php endwhile; ?>
                        </div>

                        <!-- Delivery Information -->
                        <div style="background: #f8f9fa; padding: 1.5rem; border-radius: 10px; margin-bottom: 2rem;">
                            <h4 style="margin-bottom: 1rem;">Delivery Information</h4>
                            <p><strong>Contact:</strong> <?php echo htmlspecialchars($order['contact_phone']); ?></p>
                            <p><strong>Address:</strong> <?php echo htmlspecialchars($order['delivery_address']); ?></p>
                            <p><strong>Payment Method:</strong> <?php echo htmlspecialchars($order['payment_method']); ?></p>
                        </div>

                        <!-- Order Total -->
                        <div style="border-top: 2px solid #eee; padding-top: 1rem;">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 0.8rem;">
                                <span>Subtotal:</span>
                                <span><?php echo formatPrice($order['total_amount'] - 30); ?></span>
                            </div>
                            <div style="display: flex; justify-content: space-between; margin-bottom: 0.8rem;">
                                <span>Delivery Fee:</span>
                                <span><?php echo formatPrice(30); ?></span>
                            </div>
                            <div style="display: flex; justify-content: space-between; font-size: 1.4rem; font-weight: bold; border-top: 2px solid #eee; padding-top: 1rem; color: var(--primary-color);">
                                <span>Total Paid:</span>
                                <span><?php echo formatPrice($order['total_amount']); ?></span>
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                            <a href="../pages/order-history.php" class="btn btn-primary" style="flex: 1; text-align: center;">
                                View Order History
                            </a>
                            <a href="../pages/menu.php" class="btn btn-secondary" style="flex: 1; text-align: center;">
                                Order More Food
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include '../includes/footer.php'; ?>

    <script src="../js/main.js"></script>
</body>
</html>