<?php
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $food_id = isset($_POST['food_id']) ? (int)$_POST['food_id'] : 0;

    if ($food_id > 0 && isset($_SESSION['cart'][$food_id])) {
        unset($_SESSION['cart'][$food_id]);

        echo json_encode([
            'success' => true,
            'message' => 'Item removed from cart',
            'cart_count' => getCartCount(),
            'cart_total' => getCartTotal()
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Item not found in cart'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
}
?>