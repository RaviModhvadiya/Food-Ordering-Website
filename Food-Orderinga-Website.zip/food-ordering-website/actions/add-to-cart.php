<?php
// Fix the path - go up one level from actions/ folder
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';

header('Content-Type: application/json');

// Enable error reporting for debugging (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors in JSON response

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $food_id = isset($_POST['food_id']) ? (int)$_POST['food_id'] : 0;

        if ($food_id > 0) {
            // Check if food item exists and is active
            $sql = "SELECT * FROM food_items WHERE food_id = $food_id AND active = 'YES'";
            $result = mysqli_query($conn, $sql);

            if (!$result) {
                throw new Exception('Database query failed: ' . mysqli_error($conn));
            }

            if (mysqli_num_rows($result) > 0) {
                // Initialize cart if not exists
                if (!isset($_SESSION['cart'])) {
                    $_SESSION['cart'] = array();
                }

                // Add to cart session
                if (isset($_SESSION['cart'][$food_id])) {
                    $_SESSION['cart'][$food_id]++;
                } else {
                    $_SESSION['cart'][$food_id] = 1;
                }

                echo json_encode([
                    'success' => true,
                    'message' => 'Item added to cart',
                    'cart_count' => getCartCount()
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Food item not found or unavailable'
                ]);
            }
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Invalid food ID'
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid request method'
        ]);
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred: ' . $e->getMessage()
    ]);
}
?>