<?php
require_once '../config.php';
require_once '../functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name']);
    $email = sanitize($_POST['email']);
    $subject = sanitize($_POST['subject']);
    $message = sanitize($_POST['message']);

    // Validation
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $_SESSION['error_message'] = 'Please fill in all fields';
        redirect('pages/contact.php');
    }

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error_message'] = 'Please enter a valid email address';
        redirect('pages/contact.php');
    }

    // Insert into database
    $sql = "INSERT INTO contact_messages (name, email, subject, message, created_at) 
            VALUES ('$name', '$email', '$subject', '$message', NOW())";

    if (mysqli_query($conn, $sql)) {
        $_SESSION['success_message'] = 'Thank you for contacting us! We will get back to you soon.';
        
        // Optional: Send email notification to admin
        // $admin_email = "admin@foodorder.com";
        // $email_subject = "New Contact Message: " . $subject;
        // $email_body = "Name: $name\nEmail: $email\n\nMessage:\n$message";
        // mail($admin_email, $email_subject, $email_body);
        
        redirect('pages/contact.php');
    } else {
        $_SESSION['error_message'] = 'Failed to send message. Please try again later.';
        redirect('pages/contact.php');
    }
} else {
    redirect('pages/contact.php');
}
?>