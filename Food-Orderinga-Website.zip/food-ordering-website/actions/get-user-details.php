<?php
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

if (!isLoggedIn() || !isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if (isset($_GET['user_id'])) {
    $user_id = (int)$_GET['user_id'];
    
    // Get user details
    $sql = "SELECT user_id, full_name, email, phone, address, user_type, created_at 
            FROM users WHERE user_id = $user_id";
    $result = mysqli_query($conn, $sql);
    
    if ($user = mysqli_fetch_assoc($result)) {
        // Get order statistics
        $sql_stats = "SELECT 
                        COUNT(*) as total_orders,
                        SUM(total_amount) as total_spent
                      FROM orders 
                      WHERE user_id = $user_id AND order_status != 'Cancelled'";
        $result_stats = mysqli_query($conn, $sql_stats);
        $stats = mysqli_fetch_assoc($result_stats);
        
        echo json_encode([
            'success' => true,
            'user' => $user,
            'stats' => $stats
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'User not found']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'User ID required']);
}
?>