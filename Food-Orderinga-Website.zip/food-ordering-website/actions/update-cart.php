<?php
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $food_id = isset($_POST['food_id']) ? (int)$_POST['food_id'] : 0;
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 0;

    if ($food_id > 0 && $quantity > 0) {
        if (isset($_SESSION['cart'][$food_id])) {
            $_SESSION['cart'][$food_id] = $quantity;

            // Get food price for subtotal calculation
            $sql = "SELECT price FROM food_items WHERE food_id = $food_id";
            $result = mysqli_query($conn, $sql);
            $food = mysqli_fetch_assoc($result);
            $item_subtotal = $food['price'] * $quantity;

            echo json_encode([
                'success' => true,
                'message' => 'Cart updated',
                'cart_count' => getCartCount(),
                'cart_total' => getCartTotal(),
                'item_subtotal' => $item_subtotal
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Item not found in cart'
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid parameters'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
}
?>