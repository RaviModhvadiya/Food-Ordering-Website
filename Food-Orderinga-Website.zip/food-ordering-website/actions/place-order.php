<?php
require_once '../config.php';
require_once '../functions.php';

if (!isLoggedIn()) {
    redirect('pages/login.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_SESSION['cart'])) {
    $user_id = $_SESSION['user_id'];
    $full_name = sanitize($_POST['full_name']);
    $contact_phone = sanitize($_POST['contact_phone']);
    $delivery_address = sanitize($_POST['delivery_address']);
    $payment_method = sanitize($_POST['payment_method']);
    $order_notes = isset($_POST['order_notes']) ? sanitize($_POST['order_notes']) : '';

    // Calculate total
    $subtotal = getCartTotal();
    $delivery_fee = 30;
    $total_amount = $subtotal + $delivery_fee;

    // Insert order
    $sql_order = "INSERT INTO orders (user_id, total_amount, payment_method, delivery_address, contact_phone, order_status) 
                  VALUES ($user_id, $total_amount, '$payment_method', '$delivery_address', '$contact_phone', 'Ordered')";

    if (mysqli_query($conn, $sql_order)) {
        $order_id = mysqli_insert_id($conn);

        // Insert order items
        foreach ($_SESSION['cart'] as $food_id => $quantity) {
            $sql_food = "SELECT * FROM food_items WHERE food_id = $food_id";
            $result_food = mysqli_query($conn, $sql_food);
            $food = mysqli_fetch_assoc($result_food);

            $price = $food['price'];
            $subtotal_item = $price * $quantity;

            $sql_item = "INSERT INTO order_items (order_id, food_id, quantity, price, subtotal) 
                        VALUES ($order_id, $food_id, $quantity, $price, $subtotal_item)";
            mysqli_query($conn, $sql_item);
        }

        // Clear cart
        $_SESSION['cart'] = array();

        // Set success message
        $_SESSION['success_message'] = 'Order placed successfully! Order ID: #' . $order_id;
        redirect('pages/order-success.php?order_id=' . $order_id);
    } else {
        $_SESSION['error_message'] = 'Failed to place order. Please try again.';
        redirect('pages/checkout.php');
    }
} else {
    redirect('pages/cart.php');
}
?>