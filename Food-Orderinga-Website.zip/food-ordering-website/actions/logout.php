<?php
require_once '../config.php';
require_once '../functions.php';

// Destroy session
session_destroy();

// Redirect to home
header("Location: " . SITE_URL);
exit();
?>