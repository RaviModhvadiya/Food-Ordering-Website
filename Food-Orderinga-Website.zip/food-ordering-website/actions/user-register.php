<?php
require_once '../config.php';
require_once '../functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = sanitize($_POST['full_name']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    $address = sanitize($_POST['address']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validation
    if (empty($full_name) || empty($email) || empty($phone) || empty($address) || empty($password)) {
        $_SESSION['error_message'] = 'Please fill in all fields';
        redirect('pages/register.php');
    }

    if ($password !== $confirm_password) {
        $_SESSION['error_message'] = 'Passwords do not match';
        redirect('pages/register.php');
    }

    if (strlen($password) < 6) {
        $_SESSION['error_message'] = 'Password must be at least 6 characters';
        redirect('pages/register.php');
    }

    // Check if email already exists
    $check_email = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $check_email);

    if (mysqli_num_rows($result) > 0) {
        $_SESSION['error_message'] = 'Email already registered';
        redirect('pages/register.php');
    }

    // Hash password
    $hashed_password = hashPassword($password);

    // Insert user
    $sql = "INSERT INTO users (full_name, email, phone, address, password, user_type) 
            VALUES ('$full_name', '$email', '$phone', '$address', '$hashed_password', 'customer')";

    if (mysqli_query($conn, $sql)) {
        $_SESSION['success_message'] = 'Registration successful! Please login to continue.';
        redirect('pages/login.php');
    } else {
        $_SESSION['error_message'] = 'Registration failed. Please try again.';
        redirect('pages/register.php');
    }
} else {
    redirect('pages/register.php');
}
?>