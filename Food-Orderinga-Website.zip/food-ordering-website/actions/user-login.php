<?php
require_once '../config.php';
require_once '../functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $_SESSION['error_message'] = 'Please fill in all fields';
        redirect('pages/login.php');
    }

    // Check user credentials
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) === 1) {
        $user = mysqli_fetch_assoc($result);

        // Verify password
        if (verifyPassword($password, $user['password'])) {
            // Set session variables
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_type'] = $user['user_type'];

            // Redirect based on user type
            if ($user['user_type'] === 'admin') {
                redirect('admin/index.php');
            } else {
                $_SESSION['success_message'] = 'Welcome back, ' . $user['full_name'] . '!';
                redirect('');
            }
        } else {
            $_SESSION['error_message'] = 'Invalid email or password';
            redirect('pages/login.php');
        }
    } else {
        $_SESSION['error_message'] = 'Invalid email or password';
        redirect('pages/login.php');
    }
} else {
    redirect('pages/login.php');
}
?>