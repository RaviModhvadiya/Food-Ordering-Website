-- ============================================
-- FOOD ORDERING SYSTEM - DATABASE SETUP
-- ALL VEGETARIAN ITEMS
-- ============================================
-- Drop and recreate database for clean start
DROP DATABASE IF EXISTS food_ordering;
CREATE DATABASE food_ordering;
USE food_ordering;

-- ============================================
-- TABLE: USERS
-- ============================================
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(15),
    address TEXT,
    user_type ENUM('customer', 'admin') DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_user_type (user_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE: CATEGORIES
-- ============================================
CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL,
    category_image VARCHAR(255),
    featured ENUM('YES', 'NO') DEFAULT 'NO',
    active ENUM('YES', 'NO') DEFAULT 'YES',
    INDEX idx_active (active),
    INDEX idx_featured (featured)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE: FOOD ITEMS
-- ============================================
CREATE TABLE food_items (
    food_id INT AUTO_INCREMENT PRIMARY KEY,
    food_name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    image_name VARCHAR(255),
    category_id INT,
    featured ENUM('YES', 'NO') DEFAULT 'NO',
    active ENUM('YES', 'NO') DEFAULT 'YES',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE SET NULL,
    INDEX idx_category (category_id),
    INDEX idx_active (active),
    INDEX idx_featured (featured)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE: ORDERS
-- ============================================
CREATE TABLE orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    total_amount DECIMAL(10, 2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    delivery_address TEXT NOT NULL,
    contact_phone VARCHAR(15) NOT NULL,
    order_status ENUM('Ordered', 'Processing', 'Delivered', 'Cancelled') DEFAULT 'Ordered',
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    delivery_date DATE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_status (order_status),
    INDEX idx_date (order_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE: ORDER ITEMS
-- ============================================
CREATE TABLE order_items (
    order_item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    food_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (food_id) REFERENCES food_items(food_id) ON DELETE CASCADE,
    INDEX idx_order (order_id),
    INDEX idx_food (food_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE: CONTACT MESSAGES
-- ============================================
CREATE TABLE contact_messages (
    message_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    subject VARCHAR(200),
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_date (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- INSERT DEFAULT DATA
-- ============================================

-- Insert Admin User
-- Email: admin@foodorder.com
-- Password: admin123 (plain text for easy testing)
INSERT INTO users (full_name, email, password, phone, address, user_type) VALUES 
('Administrator', 'admin@foodorder.com', 'admin123', '9876543210', 'Admin Office, FoodOrder HQ', 'admin');

-- Insert Sample Customer Users
INSERT INTO users (full_name, email, password, phone, address, user_type) VALUES 
('Rajesh Kumar', 'rajesh@example.com', 'password123', '9876543211', '12 MG Road, Bangalore', 'customer'),
('Priya Sharma', 'priya@example.com', 'password123', '9876543212', '45 Park Street, Mumbai', 'customer'),
('Amit Patel', 'amit@example.com', 'password123', '9876543213', '78 Lake View, Pune', 'customer'),
('Neha Singh', 'neha@example.com', 'password123', '9876543214', '23 Garden Road, Delhi', 'customer');

-- Insert Categories (All Vegetarian)
INSERT INTO categories (category_name, category_image, featured, active) VALUES
('Veg Pizza', 'vp.jpg', 'YES', 'YES'),
('Veg Burgers', 'vb.jpg', 'YES', 'YES'),
('Pasta', 'pa.jpg', 'YES', 'YES'),
('Indian Curries', 'ic.jpg', 'YES', 'YES'),
('South Indian', 'si.jpg', 'YES', 'YES'),
('Chinese', 'cn.jpg', 'YES', 'YES'),
('Snacks & Appetizers', 'sn.jpg', 'NO', 'YES'),
('Breads', 'br.jpg', 'NO', 'YES'),
('Rice & Biryani', 'rb.jpg', 'YES', 'YES'),
('Salads', 'sl.jpg', 'NO', 'YES'),
('Desserts', 'ds.jpg', 'YES', 'YES'),
('Beverages', 'bv.jpg', 'NO', 'YES');

-- Insert Vegetarian Food Items (Limited to 5 per category, shortened image names)
INSERT INTO food_items (food_name, description, price, image_name, category_id, featured, active) VALUES

-- Veg Pizzas (Category 1) - First 5
('Margherita Pizza', 'Classic Italian pizza with fresh mozzarella, tomato sauce, basil and oregano', 299.00, 'margherita.jpg', 1, 'YES', 'YES'),
('Farmhouse Pizza', 'Loaded with fresh vegetables - capsicum, onion, tomato, mushroom and corn', 349.00, 'farmhouse.jpg', 1, 'YES', 'YES'),
('Mexican Green Wave Pizza', 'Mexican herbs, jalapeno, capsicum, onion, tomato and cheese', 359.00, 'mexican-green.jpg', 1, 'YES', 'YES'),

-- Veg Burgers (Category 2) - First 5
('Aloo Tikki Burger', 'Crispy potato patty with lettuce, tomato, onion and special sauce', 89.00, 'aloo-tikki.jpg', 2, 'YES', 'YES'),
('Paneer Burger', 'Grilled paneer patty with cheese, lettuce and tandoori mayo', 129.00, 'paneer.jpg', 2, 'YES', 'YES'),
('Mexican Bean Burger', 'Spicy black bean patty with jalapeno, cheese and salsa', 139.00, 'mexican-bean.jpg', 2, 'NO', 'YES'),

-- Pasta (Category 3) - All 5
('Penne Arrabiata', 'Penne pasta in spicy tomato sauce with garlic and herbs', 229.00, 'arrabiata.jpg', 3, 'YES', 'YES'),
('Creamy Alfredo Pasta', 'Fettuccine in rich creamy white sauce with parmesan cheese', 249.00, 'alfredo.jpg', 3, 'YES', 'YES'),
('Mac & Cheese', 'Classic macaroni with creamy cheese sauce', 199.00, 'mac-cheese.jpg', 3, 'NO', 'YES'),

-- Indian Curries (Category 4) - First 5
('Paneer Butter Masala', 'Cottage cheese cubes in rich creamy tomato gravy', 249.00, 'paneer-butter.jpg', 4, 'YES', 'YES'),
('Dal Makhani', 'Black lentils cooked in creamy tomato gravy with butter', 189.00, 'dal-makhani.jpg', 4, 'YES', 'YES'),
('Kadai Paneer', 'Paneer cooked with capsicum, onion, tomato in kadai masala', 239.00, 'kadai-paneer.jpg', 4, 'NO', 'YES'),

-- South Indian (Category 5) - First 5
('Masala Dosa', 'Crispy rice crepe filled with spiced potato masala', 89.00, 'masala-dosa.jpg', 5, 'YES', 'YES'),
('Paper Dosa', 'Extra crispy thin rice crepe served with sambar and chutney', 79.00, 'paper-dosa.jpg', 5, 'NO', 'YES'),
('Idli Sambar (4 pcs)', 'Steamed rice cakes served with sambar and coconut chutney', 69.00, 'idli-sambar.jpg', 5, 'YES', 'YES'),

-- Chinese (Category 6) - First 5
('Veg Manchurian', 'Deep fried veggie balls in spicy manchurian sauce', 179.00, 'veg-manchurian.jpg', 6, 'YES', 'YES'),
('Veg Fried Rice', 'Wok tossed rice with vegetables and soy sauce', 149.00, 'veg-fried-rice.jpg', 6, 'YES', 'YES'),
('Spring Rolls (6 pcs)', 'Crispy vegetable spring rolls with sweet chilli sauce', 129.00, 'spring-rolls.jpg', 6, 'NO', 'YES'),

-- Snacks & Appetizers (Category 7) - First 5
('Samosa (2 pcs)', 'Crispy pastry filled with spiced potatoes and peas', 49.00, 'samosa.jpg', 7, 'YES', 'YES'),
('Pav Bhaji', 'Spicy mixed vegetable curry served with buttered bread', 119.00, 'pav-bhaji.jpg', 7, 'YES', 'YES'),
('Paneer Tikka', 'Grilled cottage cheese marinated in tandoori spices', 199.00, 'paneer-tikka.jpg', 7, 'YES', 'YES'),

-- Breads (Category 8) - First 5
('Butter Naan', 'Soft leavened bread brushed with butter', 39.00, 'butter-naan.jpg', 8, 'NO', 'YES'),
('Garlic Naan', 'Naan topped with garlic and coriander', 49.00, 'garlic-naan.jpg', 8, 'YES', 'YES'),
('Tandoori Roti', 'Whole wheat flatbread cooked in tandoor', 29.00, 'tandoori-roti.jpg', 8, 'NO', 'YES'),

-- Rice & Biryani (Category 9) - First 5
('Veg Biryani', 'Fragrant basmati rice cooked with vegetables and spices', 199.00, 'veg-biryani.jpg', 9, 'YES', 'YES'),
('Jeera Rice', 'Basmati rice tempered with cumin seeds', 99.00, 'jeera-rice.jpg', 9, 'NO', 'YES'),
('Curd Rice', 'Rice mixed with yogurt and tempering', 89.00, 'curd-rice.jpg', 9, 'NO', 'YES'),

-- Salads (Category 10) - All 4
('Green Salad', 'Fresh cucumber, tomato, onion with lemon dressing', 79.00, 'green-salad.jpg', 10, 'NO', 'YES'),
('Caesar Salad', 'Crispy lettuce with parmesan cheese and caesar dressing', 149.00, 'caesar-salad.jpg', 10, 'NO', 'YES'),
('Greek Salad', 'Cucumber, tomato, olives, feta cheese with olive oil', 169.00, 'greek-salad.jpg', 10, 'YES', 'YES'),

-- Desserts (Category 11) - First 5
('Gulab Jamun (2 pcs)', 'Soft milk dumplings soaked in sugar syrup', 69.00, 'gulab-jamun.jpg', 11, 'YES', 'YES'),
('Rasmalai (2 pcs)', 'Soft cheese patties in sweetened milk with saffron', 89.00, 'rasmalai.jpg', 11, 'YES', 'YES'),
('Gajar Halwa', 'Traditional carrot pudding with nuts and ghee', 99.00, 'gajar-halwa.jpg', 11, 'NO', 'YES'),

-- Beverages (Category 12) - First 5
('Mango Lassi', 'Sweet yogurt drink with mango pulp', 79.00, 'mango-lassi.jpg', 12, 'YES', 'YES'),
('Fresh Lime Soda', 'Refreshing lime drink with soda', 49.00, 'lime-soda.jpg', 12, 'NO', 'YES'),
('Masala Buttermilk', 'Spiced yogurt drink', 39.00, 'masala-buttermilk.jpg', 12, 'NO', 'YES');

-- Insert Sample Contact Messages
INSERT INTO contact_messages (name, email, subject, message) VALUES
('Rohit Verma', 'rohit@example.com', 'Question about delivery', 'Do you deliver to Navi Mumbai? Please let me know the delivery charges.'),
('Kavita Desai', 'kavita@example.com', 'Compliment', 'Your Paneer Butter Masala is absolutely delicious! Best I have ever tasted. Keep up the great work!'),
('Sanjay Gupta', 'sanjay@example.com', 'Suggestion', 'Would love to see more Jain food options on the menu. No onion, no garlic varieties.');

-- ============================================
-- VERIFICATION QUERIES
-- ============================================
SELECT '✅ DATABASE SETUP COMPLETE!' as Status;
SELECT '' as '';
SELECT '🔐 ADMIN LOGIN CREDENTIALS:' as Info;
SELECT 'Email: admin@foodorder.com' as '';
SELECT 'Password: admin123' as '';
SELECT '' as '';
SELECT '📊 STATISTICS:' as '';
SELECT CONCAT(COUNT(*), ' Users') as '' FROM users;
SELECT CONCAT(COUNT(*), ' Categories (All Veg)') as '' FROM categories;
SELECT CONCAT(COUNT(*), ' Food Items (Limited to 5 per category, All Veg)') as '' FROM food_items;
SELECT CONCAT(COUNT(*), ' Sample Orders') as '' FROM orders;