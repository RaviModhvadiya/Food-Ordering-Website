<?php
// Start session if not started already
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection if not already included
if (!isset($conn)) {
    require_once __DIR__ . '/config.php';
}

// Define site constants (edit according to your project)
if (!defined('SITE_URL')) {
    define('SITE_URL', 'http://localhost/food-ordering-website/');
}
if (!defined('SITE_NAME')) {
    define('SITE_NAME', 'Food Order System');
}

/* ------------------------------------------------------
|  AUTHENTICATION & USER CHECK FUNCTIONS
------------------------------------------------------ */

// Check if user is logged in
function isLoggedIn()
{
    return isset($_SESSION['user_id']);
}

// Check if user is admin
function isAdmin()
{
    return isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'admin';
}

// Redirect function
function redirect($url)
{
    header("Location: " . SITE_URL . $url);
    exit();
}

/* ------------------------------------------------------
|  SECURITY & SANITIZATION
------------------------------------------------------ */

function sanitize($data)
{
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    $data = mysqli_real_escape_string($conn, $data);
    return $data;
}

/* ------------------------------------------------------
|  FORMATTING HELPERS
------------------------------------------------------ */

function formatPrice($price)
{
    return '₹' . number_format((float)$price, 2);
}

function formatDate($date)
{
    return date('d M Y', strtotime($date));
}

/* ------------------------------------------------------
|  CART FUNCTIONS
------------------------------------------------------ */

function getCartTotal()
{
    global $conn;
    $total = 0;
    if (!empty($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $food_id => $quantity) {
            $food_id = (int)$food_id;
            $sql = "SELECT price FROM food_items WHERE food_id = $food_id";
            $result = mysqli_query($conn, $sql);
            if ($row = mysqli_fetch_assoc($result)) {
                $total += $row['price'] * $quantity;
            }
        }
    }
    return $total;
}

function getCartCount()
{
    $count = 0;
    if (!empty($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $quantity) {
            $count += $quantity;
        }
    }
    return $count;
}

/* ------------------------------------------------------
|  UI MESSAGES
------------------------------------------------------ */

function showSuccess($message)
{
    return '<div class="alert alert-success animate-fade-in">' . htmlspecialchars($message) . '</div>';
}

function showError($message)
{
    return '<div class="alert alert-error animate-fade-in">' . htmlspecialchars($message) . '</div>';
}

/* ------------------------------------------------------
|  IMAGE UPLOAD HANDLER
------------------------------------------------------ */

function uploadImage($file, $folder = 'images/')
{
    if (!isset($file['tmp_name']) || empty($file['tmp_name'])) {
        return ['success' => false, 'message' => 'No file uploaded.'];
    }

    $document_root = $_SERVER['DOCUMENT_ROOT'];
    $folder = '/' . trim($folder, '/') . '/';
    $target_dir = $document_root . $folder;

    if (!file_exists($target_dir)) {
        if (!mkdir($target_dir, 0755, true)) {
            return ['success' => false, 'message' => 'Failed to create upload directory.'];
        }
    }

    if (!is_writable($target_dir)) {
        chmod($target_dir, 0755);
        if (!is_writable($target_dir)) {
            return ['success' => false, 'message' => 'Upload directory is not writable.'];
        }
    }

    $imageFileType = strtolower(pathinfo($file["name"], PATHINFO_EXTENSION));
    $newFileName = time() . '_' . uniqid() . '.' . $imageFileType;
    $target_file = $target_dir . $newFileName;

    $check = getimagesize($file["tmp_name"]);
    if ($check === false) {
        return ['success' => false, 'message' => 'File is not an image.'];
    }

    if ($file["size"] > 5000000) {
        return ['success' => false, 'message' => 'File too large. Max 5MB allowed.'];
    }

    $allowed_types = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    if (!in_array($imageFileType, $allowed_types)) {
        return ['success' => false, 'message' => 'Only JPG, JPEG, PNG, GIF & WEBP allowed.'];
    }

    if (move_uploaded_file($file["tmp_name"], $target_file)) {
        return ['success' => true, 'filename' => $newFileName];
    } else {
        return ['success' => false, 'message' => 'Error uploading file.'];
    }
}

/* ------------------------------------------------------
|  ORDER / PAYMENT HELPERS
------------------------------------------------------ */

function generateOrderNumber()
{
    return 'ORD' . time() . rand(1000, 9999);
}

/* ------------------------------------------------------
|  EMAIL SENDER
------------------------------------------------------ */

function sendEmail($to, $subject, $message)
{
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= 'From: ' . SITE_NAME . ' <noreply@foodorder.com>' . "\r\n";

    return mail($to, $subject, $message, $headers);
}

/* ------------------------------------------------------
|  PAGINATION
------------------------------------------------------ */

function paginate($total_records, $records_per_page, $current_page, $url)
{
    $total_pages = ceil($total_records / $records_per_page);
    if ($total_pages <= 1) return ''; // No pagination needed

    $pagination = '<div class="pagination">';

    if ($current_page > 1) {
        $pagination .= '<a href="' . $url . '?page=' . ($current_page - 1) . '" class="page-link">← Previous</a>';
    }

    for ($i = 1; $i <= $total_pages; $i++) {
        $active = ($i == $current_page) ? 'active' : '';
        $pagination .= '<a href="' . $url . '?page=' . $i . '" class="page-link ' . $active . '">' . $i . '</a>';
    }

    if ($current_page < $total_pages) {
        $pagination .= '<a href="' . $url . '?page=' . ($current_page + 1) . '" class="page-link">Next →</a>';
    }

    $pagination .= '</div>';
    return $pagination;
}

/* ------------------------------------------------------
|  PASSWORD FUNCTIONS
------------------------------------------------------ */

function verifyPassword($password, $hash)
{
    if (password_verify($password, $hash)) {
        return true;
    }
    return $password === $hash; // For old unhashed passwords
}

function hashPassword($password)
{
    return password_hash($password, PASSWORD_DEFAULT);
}
