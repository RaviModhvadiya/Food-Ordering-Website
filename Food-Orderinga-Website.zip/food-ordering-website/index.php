<?php
require_once 'config.php';
require_once 'functions.php';

// Get featured categories
$sql_categories = "SELECT * FROM categories WHERE featured = 'YES' AND active = 'YES' LIMIT 6";
$result_categories = mysqli_query($conn, $sql_categories);

// Get featured food items
$sql_featured = "SELECT f.*, c.category_name 
                 FROM food_items f 
                 LEFT JOIN categories c ON f.category_id = c.category_id 
                 WHERE f.featured = 'YES' AND f.active = 'YES' 
                 LIMIT 8";
$result_featured = mysqli_query($conn, $sql_featured);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - Order Food Online</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/animations.css">
    <link rel="stylesheet" href="css/responsive.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <!-- Hero Section -->
    <section class="hero animate-fade-in">
        <div class="container">
            <h1 class="animate-slide-left">Delicious Food, Delivered Fast</h1>
            <p class="animate-slide-right">Order your favorite meals from the best restaurants</p>
            <a href="pages/menu.php" class="btn btn-primary animate-scale">Order Now</a>
        </div>
    </section>

    <!-- Featured Categories -->
    <section class="py-3">
        <div class="container">
            <div class="section-title">
                <h2>Browse by Category</h2>
                <p>Choose from our wide variety of food categories</p>
            </div>

            <div class="category-grid stagger-animation">
                <?php
                if (mysqli_num_rows($result_categories) > 0) {
                    while ($category = mysqli_fetch_assoc($result_categories)) {
                        ?>
                        <a href="pages/menu.php?category=<?php echo $category['category_id']; ?>" class="category-card hover-lift">
                            <img src="images/<?php echo $category['category_image'] ?: 'default-category.jpg'; ?>" 
                                 alt="<?php echo $category['category_name']; ?>">
                            <h3><?php echo $category['category_name']; ?></h3>
                        </a>
                        <?php
                    }
                } else {
                    echo '<p class="text-center">No categories available.</p>';
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Featured Foods -->
    <section class="py-3">
        <div class="container">
            <div class="section-title">
                <h2>Featured Dishes</h2>
                <p>Try our most popular and delicious items</p>
            </div>

            <div class="food-grid stagger-animation">
                <?php
                if (mysqli_num_rows($result_featured) > 0) {
                    while ($food = mysqli_fetch_assoc($result_featured)) {
                        ?>
                        <div class="food-card hover-lift hover-zoom">
                            <img src="images/foods/<?php echo $food['image_name'] ?: 'default-food.jpg'; ?>" 
                                 alt="<?php echo $food['food_name']; ?>">
                            <div class="food-card-body">
                                <h3><?php echo $food['food_name']; ?></h3>
                                <p><?php echo substr($food['description'], 0, 80) . '...'; ?></p>
                                <div class="food-price"><?php echo formatPrice($food['price']); ?></div>
                                <button onclick="addToCart(<?php echo $food['food_id']; ?>, '<?php echo addslashes($food['food_name']); ?>', <?php echo $food['price']; ?>)" 
                                        class="btn btn-primary btn-ripple">
                                    Add to Cart
                                </button>
                            </div>
                        </div>
                        <?php
                    }
                } else {
                    echo '<p class="text-center">No featured items available.</p>';
                }
                ?>
            </div>

            <div class="text-center mt-3">
                <a href="pages/menu.php" class="btn btn-secondary">View Full Menu</a>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="py-3" style="background: var(--light-color);">
        <div class="container">
            <div class="section-title">
                <h2>Why Choose Us?</h2>
                <p>We provide the best service for our customers</p>
            </div>

            <div class="food-grid">
                <div class="food-card text-center animate-fade-in">
                    <div class="food-card-body">
                        <div style="font-size: 3rem; color: var(--primary-color); margin-bottom: 1rem;">🚚</div>
                        <h3>Fast Delivery</h3>
                        <p>Get your food delivered hot and fresh within 30 minutes</p>
                    </div>
                </div>

                <div class="food-card text-center animate-fade-in">
                    <div class="food-card-body">
                        <div style="font-size: 3rem; color: var(--secondary-color); margin-bottom: 1rem;">🍕</div>
                        <h3>Quality Food</h3>
                        <p>We serve only the highest quality ingredients and dishes</p>
                    </div>
                </div>

                <div class="food-card text-center animate-fade-in">
                    <div class="food-card-body">
                        <div style="font-size: 3rem; color: var(--success-color); margin-bottom: 1rem;">💰</div>
                        <h3>Best Prices</h3>
                        <p>Affordable prices with amazing deals and offers</p>
                    </div>
                </div>

                <div class="food-card text-center animate-fade-in">
                    <div class="food-card-body">
                        <div style="font-size: 3rem; color: var(--warning-color); margin-bottom: 1rem;">⭐</div>
                        <h3>5-Star Rating</h3>
                        <p>Trusted by thousands of happy customers</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>

    <script src="js/main.js"></script>
    <script src="js/cart.js"></script>
</body>
</html>