<?php
require_once '../config.php';
require_once '../functions.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect('pages/login.php');
}

$success = '';
$error = '';

/* -------------------------------
   DELETE FOOD ITEM
-------------------------------- */
if (isset($_GET['delete'])) {
    $food_id = (int)$_GET['delete'];

    // Get image before deleting
    $sql_img = "SELECT image_name FROM food_items WHERE food_id = $food_id";
    $result_img = mysqli_query($conn, $sql_img);
    $food_img = mysqli_fetch_assoc($result_img);

    // Delete food
    $sql = "DELETE FROM food_items WHERE food_id = $food_id";
    if (mysqli_query($conn, $sql)) {
        // Delete image file if exists
        if ($food_img && $food_img['image_name']) {
            $img_path = $_SERVER['DOCUMENT_ROOT'] . '/images/foods/' . $food_img['image_name'];
            if (file_exists($img_path)) {
                unlink($img_path);
            }
        }
        $success = 'Food item deleted successfully!';
    } else {
        $error = 'Failed to delete food item: ' . mysqli_error($conn);
    }
}

/* -------------------------------
   ADD / EDIT FOOD ITEM
-------------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $food_name   = sanitize($_POST['food_name']);
    $description = sanitize($_POST['description']);
    $price       = (float)$_POST['price'];
    $category_id = (int)$_POST['category_id'];
    $featured    = sanitize($_POST['featured']);
    $active      = sanitize($_POST['active']);
    $image_name  = '';
    $error       = '';

    // Handle image upload if provided
    if (isset($_FILES['image_name']) && $_FILES['image_name']['error'] === 0) {
        $upload = uploadImage($_FILES['image_name'], 'images/foods/');
        if ($upload['success']) {
            $image_name = $upload['filename'];
        } else {
            $error = $upload['message'];
        }
    } else if (isset($_FILES['image_name']) && $_FILES['image_name']['error'] !== 4) {
        // Error occurred, but not "no file" error
        $error = 'Image upload error: ' . $_FILES['image_name']['error'];
    }

    // If no upload or validation errors
    if (empty($error)) {
        if (isset($_POST['food_id']) && !empty($_POST['food_id'])) {
            /* ---------- UPDATE EXISTING FOOD ---------- */
            $food_id = (int)$_POST['food_id'];

            // If new image uploaded → delete old one
            if ($image_name) {
                $sql_old = "SELECT image_name FROM food_items WHERE food_id = $food_id";
                $result_old = mysqli_query($conn, $sql_old);
                $old_food = mysqli_fetch_assoc($result_old);
                if ($old_food && $old_food['image_name']) {
                    $old_img_path = $_SERVER['DOCUMENT_ROOT'] . '/images/foods/' . $old_food['image_name'];
                    if (file_exists($old_img_path)) {
                        unlink($old_img_path);
                    }
                }
            }

            // Update food record
            $sql = "UPDATE food_items SET 
                        food_name = '$food_name',
                        description = '$description',
                        price = $price,
                        category_id = $category_id,
                        featured = '$featured',
                        active = '$active'";
            if ($image_name) {
                $sql .= ", image_name = '$image_name'";
            }
            $sql .= " WHERE food_id = $food_id";

            if (mysqli_query($conn, $sql)) {
                header("Location: manage-foods.php?success=updated");
                exit();
            } else {
                $error = 'Failed to update food item: ' . mysqli_error($conn);
            }
        } else {
            /* ---------- ADD NEW FOOD ---------- */
            $sql = "INSERT INTO food_items 
                    (food_name, description, price, image_name, category_id, featured, active)
                    VALUES 
                    ('$food_name', '$description', $price, '$image_name', $category_id, '$featured', '$active')";

            if (mysqli_query($conn, $sql)) {
                header("Location: manage-foods.php?success=added");
                exit();
            } else {
                $error = 'Failed to add food item: ' . mysqli_error($conn);
            }
        }
    }
}

/* -------------------------------
   SHOW SUCCESS / EDIT MODE
-------------------------------- */
if (isset($_GET['success'])) {
    if ($_GET['success'] === 'added') $success = 'Food item added successfully!';
    if ($_GET['success'] === 'updated') $success = 'Food item updated successfully!';
}

// Fetch food item for editing
$edit_food = null;
if (isset($_GET['edit'])) {
    $food_id = (int)$_GET['edit'];
    $sql = "SELECT * FROM food_items WHERE food_id = $food_id";
    $result = mysqli_query($conn, $sql);
    $edit_food = mysqli_fetch_assoc($result);
}

// Get categories
$sql_categories = "SELECT * FROM categories WHERE active = 'YES' ORDER BY category_name";
$result_categories = mysqli_query($conn, $sql_categories);

// Pagination setup
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$records_per_page = 10;
$offset = ($page - 1) * $records_per_page;

// Fetch food list
$sql = "SELECT f.*, c.category_name 
        FROM food_items f 
        LEFT JOIN categories c ON f.category_id = c.category_id 
        ORDER BY f.food_id DESC 
        LIMIT $offset, $records_per_page";
$result = mysqli_query($conn, $sql);

// Count total records
$sql_count = "SELECT COUNT(*) as total FROM food_items";
$result_count = mysqli_query($conn, $sql_count);
$total_records = mysqli_fetch_assoc($result_count)['total'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Foods - Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/animations.css">
    <link rel="stylesheet" href="../css/responsive.css">
    <style>
        .image-preview {
            margin-top: 10px;
            max-width: 200px;
            border-radius: 10px;
            display: none;
        }

        .image-preview.show {
            display: block;
        }

        .upload-info {
            font-size: 0.85rem;
            color: #666;
            margin-top: 5px;
        }
    </style>
</head>

<body>

    <header style="background:linear-gradient(135deg,#2c3e50,#34495e);">
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">⚙️ Admin Panel</a>
                <button class="menu-toggle">☰</button>
                <ul class="nav-links">
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="manage-categories.php">Categories</a></li>
                    <li><a href="manage-foods.php">Foods</a></li>
                    <li><a href="manage-orders.php">Orders</a></li>
                    <li><a href="manage-users.php">Users</a></li>
                    <li><a href="../">View Website</a></li>
                    <li><a href="../actions/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="py-3">
        <div class="container">
            <?php if ($success) echo showSuccess($success); ?>
            <?php if ($error) echo showError($error); ?>

            <div style="display:grid;grid-template-columns:1fr 450px;gap:2rem;">
                <!-- FOOD LIST -->
                <div>
                    <h2 style="margin-bottom:1.5rem;">All Food Items (<?php echo $total_records; ?>)</h2>
                    <div class="food-card">
                        <div class="food-card-body">
                            <div class="table-responsive">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Image</th>
                                            <th>Name</th>
                                            <th>Category</th>
                                            <th>Price</th>
                                            <th>Featured</th>
                                            <th>Active</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (mysqli_num_rows($result) > 0): ?>
                                            <?php while ($food = mysqli_fetch_assoc($result)): ?>
                                                <tr>
                                                    <td><?php echo $food['food_id']; ?></td>
                                                    <td>
                                                        <?php if ($food['image_name'] && file_exists($_SERVER['DOCUMENT_ROOT'] . '/images/foods/' . $food['image_name'])): ?>
                                                            <img src="../images/foods/<?php echo $food['image_name']; ?>" style="width:60px;height:60px;object-fit:cover;border-radius:8px;">
                                                        <?php else: ?>
                                                            <div style="width:60px;height:60px;background:#ddd;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:24px;">🍽️</div>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <strong><?php echo htmlspecialchars($food['food_name']); ?></strong><br>
                                                        <small style="color:#666;"><?php echo substr($food['description'], 0, 40) . '...'; ?></small>
                                                    </td>
                                                    <td><?php echo htmlspecialchars($food['category_name']); ?></td>
                                                    <td><strong><?php echo formatPrice($food['price']); ?></strong></td>
                                                    <td><span class="badge <?php echo $food['featured'] === 'YES' ? 'badge-success' : 'badge-secondary'; ?>"><?php echo $food['featured']; ?></span></td>
                                                    <td><span class="badge <?php echo $food['active'] === 'YES' ? 'badge-success' : 'badge-danger'; ?>"><?php echo $food['active']; ?></span></td>
                                                    <td>
                                                        <a href="?edit=<?php echo $food['food_id']; ?>" class="btn btn-primary" style="padding:0.4rem 0.8rem;margin-right:0.5rem;">Edit</a>
                                                        <a href="?delete=<?php echo $food['food_id']; ?>" class="btn btn-danger delete-btn" style="padding:0.4rem 0.8rem;" onclick="return confirm('Are you sure you want to delete this food item?');">Delete</a>
                                                    </td>
                                                </tr>
                                            <?php endwhile; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="8" style="text-align:center;padding:2rem;color:#666;">No food items found</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php if ($total_records > $records_per_page) echo paginate($total_records, $records_per_page, $page, 'manage-foods.php'); ?>
                        </div>
                    </div>
                </div>

                <!-- ADD / EDIT FORM -->
                <div>
                    <div class="food-card" style="position:sticky;top:100px;">
                        <div class="food-card-body" style="padding:2rem;">
                            <h3 style="margin-bottom:1.5rem;"><?php echo $edit_food ? 'Edit Food Item' : 'Add New Food'; ?></h3>
                            <form method="POST" enctype="multipart/form-data" id="foodForm">
                                <?php if ($edit_food): ?>
                                    <input type="hidden" name="food_id" value="<?php echo $edit_food['food_id']; ?>">
                                <?php endif; ?>

                                <div class="form-group">
                                    <label for="food_name">Food Name *</label>
                                    <input type="text" id="food_name" name="food_name" class="form-control" value="<?php echo $edit_food ? htmlspecialchars($edit_food['food_name']) : ''; ?>" required>
                                </div>

                                <div class="form-group">
                                    <label for="description">Description *</label>
                                    <textarea id="description" name="description" class="form-control" rows="3" required><?php echo $edit_food ? htmlspecialchars($edit_food['description']) : ''; ?></textarea>
                                </div>

                                <div class="form-group">
                                    <label for="price">Price (₹) *</label>
                                    <input type="number" id="price" name="price" class="form-control" step="0.01" min="0" value="<?php echo $edit_food ? $edit_food['price'] : ''; ?>" required>
                                </div>

                                <div class="form-group">
                                    <label for="category_id">Category *</label>
                                    <select id="category_id" name="category_id" class="form-control" required>
                                        <option value="">Select Category</option>
                                        <?php
                                        mysqli_data_seek($result_categories, 0);
                                        while ($cat = mysqli_fetch_assoc($result_categories)): ?>
                                            <option value="<?php echo $cat['category_id']; ?>" <?php echo ($edit_food && $edit_food['category_id'] == $cat['category_id']) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($cat['category_name']); ?>
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="image_name">Food Image <?php echo $edit_food ? '(Leave empty to keep current)' : '*'; ?></label>
                                    <?php if ($edit_food && $edit_food['image_name']): ?>
                                        <div style="margin-bottom:1rem;">
                                            <p style="font-size:0.9rem;color:#666;margin-bottom:0.5rem;">Current Image:</p>
                                            <?php if (file_exists($_SERVER['DOCUMENT_ROOT'] . '/images/foods/' . $edit_food['image_name'])): ?>
                                                <img src="../images/foods/<?php echo $edit_food['image_name']; ?>" style="width:100%;max-width:200px;border-radius:10px;">
                                            <?php else: ?>
                                                <p style="color:#dc3545;font-size:0.9rem;">⚠️ Image not found</p>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>

                                    <input type="file" id="image_name" name="image_name" class="form-control" accept="image/jpeg,image/jpg,image/png,image/gif,image/webp" <?php echo !$edit_food ? 'required' : ''; ?> onchange="previewImage(this)">
                                    <p class="upload-info">Accepted: JPG, PNG, GIF, WEBP (Max 5MB)</p>
                                    <img id="imagePreview" class="image-preview" alt="Preview">
                                </div>

                                <div class="form-group">
                                    <label for="featured">Featured</label>
                                    <select id="featured" name="featured" class="form-control">
                                        <option value="YES" <?php echo ($edit_food && $edit_food['featured'] === 'YES') ? 'selected' : ''; ?>>YES</option>
                                        <option value="NO" <?php echo (!$edit_food || $edit_food['featured'] === 'NO') ? 'selected' : ''; ?>>NO</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="active">Active</label>
                                    <select id="active" name="active" class="form-control">
                                        <option value="YES" <?php echo (!$edit_food || $edit_food['active'] === 'YES') ? 'selected' : ''; ?>>YES</option>
                                        <option value="NO" <?php echo ($edit_food && $edit_food['active'] === 'NO') ? 'selected' : ''; ?>>NO</option>
                                    </select>
                                </div>

                                <button type="submit" class="btn btn-primary btn-ripple" style="width:100%;">
                                    <?php echo $edit_food ? '✓ Update Food' : '+ Add Food'; ?>
                                </button>

                                <?php if ($edit_food): ?>
                                    <a href="manage-foods.php" class="btn btn-secondary" style="width:100%;margin-top:0.5rem;text-align:center;display:block;">Cancel Edit</a>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="../js/main.js"></script>
    <script>
        function previewImage(input) {
            const preview = document.getElementById('imagePreview');
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.classList.add('show');
                }
                reader.readAsDataURL(input.files[0]);
            } else {
                preview.classList.remove('show');
            }
        }
    </script>
</body>

</html>