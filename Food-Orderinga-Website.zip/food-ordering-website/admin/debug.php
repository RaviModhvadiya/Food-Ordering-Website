<?php
// Save this as: admin/debug.php
// Access it at: localhost/food-ordering-website/admin/debug.php

require_once '../config.php';

echo "<h1>Admin Login Debug Tool</h1>";
echo "<style>
    body { font-family: Arial; padding: 20px; background: #f5f5f5; }
    .success { background: #d4edda; padding: 15px; margin: 10px 0; border-radius: 5px; border: 1px solid #c3e6cb; }
    .error { background: #f8d7da; padding: 15px; margin: 10px 0; border-radius: 5px; border: 1px solid #f5c6cb; }
    .info { background: #d1ecf1; padding: 15px; margin: 10px 0; border-radius: 5px; border: 1px solid #bee5eb; }
    table { width: 100%; border-collapse: collapse; background: white; margin: 20px 0; }
    th, td { padding: 12px; text-align: left; border: 1px solid #ddd; }
    th { background: #007bff; color: white; }
    code { background: #f4f4f4; padding: 2px 6px; border-radius: 3px; }
    .btn { display: inline-block; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px; margin: 10px 0; }
</style>";

// 1. Check Database Connection
echo "<h2>1. Database Connection</h2>";
if ($conn) {
    echo "<div class='success'>✅ Database Connected Successfully</div>";
    echo "<div class='info'><strong>Database:</strong> " . DB_NAME . "</div>";
} else {
    echo "<div class='error'>❌ Database Connection Failed: " . mysqli_connect_error() . "</div>";
    exit;
}

// 2. Check if users table exists
echo "<h2>2. Users Table Check</h2>";
$check_table = mysqli_query($conn, "SHOW TABLES LIKE 'users'");
if (mysqli_num_rows($check_table) > 0) {
    echo "<div class='success'>✅ Users table exists</div>";
} else {
    echo "<div class='error'>❌ Users table does NOT exist</div>";
    exit;
}

// 3. Check Admin Users
echo "<h2>3. Admin Users in Database</h2>";
$sql = "SELECT user_id, full_name, email, user_type, password, created_at FROM users WHERE user_type = 'admin'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    echo "<div class='success'>✅ Found " . mysqli_num_rows($result) . " admin user(s)</div>";
    echo "<table>";
    echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>User Type</th><th>Password (first 50 chars)</th><th>Created</th></tr>";
    
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['user_id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['full_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
        echo "<td>" . htmlspecialchars($row['user_type']) . "</td>";
        echo "<td><code>" . substr($row['password'], 0, 50) . "...</code></td>";
        echo "<td>" . $row['created_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<div class='error'>❌ No admin users found in database!</div>";
    echo "<div class='info'><strong>Solution:</strong> Run the SQL query below to create an admin account</div>";
}

// 4. Test Password Hashing
echo "<h2>4. Password Test</h2>";
$test_password = "admin123";
$hashed = password_hash($test_password, PASSWORD_DEFAULT);
echo "<div class='info'>";
echo "<strong>Test Password:</strong> <code>admin123</code><br>";
echo "<strong>Hashed Version:</strong> <code>" . $hashed . "</code><br>";
echo "<strong>Verification:</strong> " . (password_verify($test_password, $hashed) ? "✅ Works" : "❌ Failed");
echo "</div>";

// 5. Check Session
echo "<h2>5. Session Check</h2>";
if (session_status() === PHP_SESSION_ACTIVE) {
    echo "<div class='success'>✅ Session is active</div>";
    if (!empty($_SESSION)) {
        echo "<div class='info'><strong>Current Session Data:</strong><br>";
        echo "<pre>" . print_r($_SESSION, true) . "</pre></div>";
    } else {
        echo "<div class='info'>Session is empty (not logged in)</div>";
    }
} else {
    echo "<div class='error'>❌ Session is NOT active</div>";
}

// 6. Check Functions
echo "<h2>6. Functions Check</h2>";
if (function_exists('isLoggedIn')) {
    echo "<div class='success'>✅ isLoggedIn() function exists</div>";
} else {
    echo "<div class='error'>❌ isLoggedIn() function NOT found</div>";
}

if (function_exists('isAdmin')) {
    echo "<div class='success'>✅ isAdmin() function exists</div>";
} else {
    echo "<div class='error'>❌ isAdmin() function NOT found</div>";
}

// 7. Test Login with Demo Credentials
echo "<h2>7. Test Login Form</h2>";
echo "<div class='info'>";
echo "<p>Use this form to test login. Check browser console (F12) for any JavaScript errors.</p>";
echo "</div>";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test_login'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    
    echo "<div class='info'><strong>Testing Login...</strong></div>";
    
    $sql = "SELECT * FROM users WHERE email = '$email' AND user_type = 'admin'";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) === 1) {
        $user = mysqli_fetch_assoc($result);
        echo "<div class='success'>✅ User found in database</div>";
        
        // Test password
        $password_match_hash = password_verify($password, $user['password']);
        $password_match_plain = ($password === $user['password']);
        
        echo "<div class='info'>";
        echo "<strong>Password Check:</strong><br>";
        echo "Hashed password match: " . ($password_match_hash ? "✅ YES" : "❌ NO") . "<br>";
        echo "Plain text match: " . ($password_match_plain ? "✅ YES" : "❌ NO") . "<br>";
        echo "</div>";
        
        if ($password_match_hash || $password_match_plain) {
            echo "<div class='success'>✅ PASSWORD CORRECT! Login should work.</div>";
            
            // Try setting session
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_type'] = $user['user_type'];
            
            echo "<div class='success'>✅ Session variables set successfully</div>";
            echo "<div class='info'><pre>" . print_r($_SESSION, true) . "</pre></div>";
        } else {
            echo "<div class='error'>❌ PASSWORD INCORRECT</div>";
            echo "<div class='info'>Stored password: <code>" . substr($user['password'], 0, 50) . "...</code></div>";
        }
    } else {
        echo "<div class='error'>❌ User not found with email: " . htmlspecialchars($email) . "</div>";
    }
}

?>

<form method="POST" action="" style="background: white; padding: 20px; border-radius: 5px; max-width: 400px;">
    <h3>Test Login</h3>
    <div style="margin-bottom: 15px;">
        <label style="display: block; margin-bottom: 5px;">Email:</label>
        <input type="email" name="email" value="admin@foodorder.com" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 3px;" required>
    </div>
    <div style="margin-bottom: 15px;">
        <label style="display: block; margin-bottom: 5px;">Password:</label>
        <input type="password" name="password" value="admin123" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 3px;" required>
    </div>
    <button type="submit" name="test_login" class="btn">🔍 Test Login</button>
</form>

<?php
// 8. SQL Fix Scripts
echo "<h2>8. Quick Fix SQL Scripts</h2>";
echo "<div class='info'>";
echo "<h3>Option 1: Create Admin User (Run in phpMyAdmin)</h3>";
echo "<textarea readonly style='width: 100%; height: 150px; font-family: monospace; padding: 10px;'>";
echo "-- Delete existing admin (if any)
DELETE FROM users WHERE email = 'admin@foodorder.com';

-- Create new admin with hashed password
INSERT INTO users (full_name, email, phone, address, password, user_type, created_at) 
VALUES ('Administrator', 'admin@foodorder.com', '9876543210', 'Admin Office', '" . password_hash('admin123', PASSWORD_DEFAULT) . "', 'admin', NOW());

-- Verify
SELECT * FROM users WHERE user_type = 'admin';";
echo "</textarea>";

echo "<h3>Option 2: Create Admin with Plain Password (Testing Only)</h3>";
echo "<textarea readonly style='width: 100%; height: 100px; font-family: monospace; padding: 10px;'>";
echo "-- WARNING: Plain text password - for testing only!
INSERT INTO users (full_name, email, phone, address, password, user_type, created_at) 
VALUES ('Admin User', 'admin@foodorder.com', '9876543210', 'Test Address', 'admin123', 'admin', NOW());";
echo "</textarea>";
echo "</div>";

echo "<h2>9. File Paths Check</h2>";
echo "<div class='info'>";
echo "<strong>Current File:</strong> " . __FILE__ . "<br>";
echo "<strong>Document Root:</strong> " . $_SERVER['DOCUMENT_ROOT'] . "<br>";
echo "<strong>Script Path:</strong> " . $_SERVER['SCRIPT_NAME'] . "<br>";
echo "</div>";

echo "<div style='margin-top: 30px; padding: 20px; background: #fff3cd; border-radius: 5px;'>";
echo "<h3>📋 Next Steps:</h3>";
echo "<ol>";
echo "<li>Check if admin user exists in the table above</li>";
echo "<li>If no admin user: Run the SQL script in phpMyAdmin</li>";
echo "<li>Use the test login form above to verify credentials</li>";
echo "<li>Check browser console (F12) for JavaScript errors</li>";
echo "<li>Try logging in again at <a href='login.php'>login.php</a></li>";
echo "</ol>";
echo "</div>";

echo "<div style='text-align: center; margin-top: 20px;'>";
echo "<a href='login.php' class='btn'>🔐 Go to Login Page</a>";
echo "</div>";
?>