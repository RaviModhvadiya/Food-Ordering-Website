<?php
require_once '../config.php';
require_once '../functions.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect('pages/login.php');
}

$success = '';
$error = '';

// Handle Delete
if (isset($_GET['delete'])) {
    $cat_id = (int)$_GET['delete'];
    $sql = "DELETE FROM categories WHERE category_id = $cat_id";
    if (mysqli_query($conn, $sql)) {
        $success = 'Category deleted successfully!';
    } else {
        $error = 'Failed to delete category';
    }
}

// Handle Add/Edit Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category_name = sanitize($_POST['category_name']);
    $featured = sanitize($_POST['featured']);
    $active = sanitize($_POST['active']);
    $category_image = '';

    // Handle image upload
    if (isset($_FILES['category_image']) && $_FILES['category_image']['error'] === 0) {
        $upload = uploadImage($_FILES['category_image'], 'images/');
        if ($upload['success']) {
            $category_image = $upload['filename'];
        } else {
            $error = $upload['message'];
        }
    }

    if (empty($error)) {
        if (isset($_POST['category_id']) && !empty($_POST['category_id'])) {
            // Update
            $category_id = (int)$_POST['category_id'];
            $sql = "UPDATE categories SET 
                    category_name = '$category_name',
                    featured = '$featured',
                    active = '$active'";
            if ($category_image) {
                $sql .= ", category_image = '$category_image'";
            }
            $sql .= " WHERE category_id = $category_id";
            
            if (mysqli_query($conn, $sql)) {
                $success = 'Category updated successfully!';
            } else {
                $error = 'Failed to update category';
            }
        } else {
            // Insert
            $sql = "INSERT INTO categories (category_name, category_image, featured, active) 
                    VALUES ('$category_name', '$category_image', '$featured', '$active')";
            
            if (mysqli_query($conn, $sql)) {
                $success = 'Category added successfully!';
            } else {
                $error = 'Failed to add category';
            }
        }
    }
}

// Get category for edit
$edit_category = null;
if (isset($_GET['edit'])) {
    $cat_id = (int)$_GET['edit'];
    $sql = "SELECT * FROM categories WHERE category_id = $cat_id";
    $result = mysqli_query($conn, $sql);
    $edit_category = mysqli_fetch_assoc($result);
}

// Get all categories
$sql = "SELECT * FROM categories ORDER BY category_id DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Categories - Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/animations.css">
    <link rel="stylesheet" href="../css/responsive.css">
</head>
<body>
    <!-- Admin Header -->
    <header style="background: linear-gradient(135deg, #2c3e50, #34495e);">
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">⚙️ Admin Panel</a>
                <button class="menu-toggle">☰</button>
                <ul class="nav-links">
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="manage-categories.php">Categories</a></li>
                    <li><a href="manage-foods.php">Foods</a></li>
                    <li><a href="manage-orders.php">Orders</a></li>
                    <li><a href="manage-users.php">Users</a></li>
                    <li><a href="../">View Website</a></li>
                    <li><a href="../actions/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="py-3">
        <div class="container">
            <?php if ($success): ?>
                <?php echo showSuccess($success); ?>
            <?php endif; ?>
            <?php if ($error): ?>
                <?php echo showError($error); ?>
            <?php endif; ?>

            <div style="display: grid; grid-template-columns: 1fr 400px; gap: 2rem;">
                <!-- Categories List -->
                <div>
                    <h2 style="margin-bottom: 1.5rem;">All Categories</h2>
                    
                    <div class="food-card">
                        <div class="food-card-body">
                            <div class="table-responsive">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Image</th>
                                            <th>Name</th>
                                            <th>Featured</th>
                                            <th>Active</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($cat = mysqli_fetch_assoc($result)): ?>
                                        <tr>
                                            <td><?php echo $cat['category_id']; ?></td>
                                            <td>
                                                <?php if ($cat['category_image']): ?>
                                                    <img src="../images/<?php echo $cat['category_image']; ?>" 
                                                         style="width: 50px; height: 50px; object-fit: cover; border-radius: 50%;">
                                                <?php else: ?>
                                                    <div style="width: 50px; height: 50px; background: #ddd; border-radius: 50%; display: flex; align-items: center; justify-content: center;">📁</div>
                                                <?php endif; ?>
                                            </td>
                                            <td><strong><?php echo htmlspecialchars($cat['category_name']); ?></strong></td>
                                            <td>
                                                <span class="badge <?php echo $cat['featured'] === 'YES' ? 'badge-success' : 'badge-secondary'; ?>">
                                                    <?php echo $cat['featured']; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge <?php echo $cat['active'] === 'YES' ? 'badge-success' : 'badge-danger'; ?>">
                                                    <?php echo $cat['active']; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="?edit=<?php echo $cat['category_id']; ?>" 
                                                   class="btn btn-primary" 
                                                   style="padding: 0.4rem 0.8rem; margin-right: 0.5rem;">Edit</a>
                                                <a href="?delete=<?php echo $cat['category_id']; ?>" 
                                                   class="btn btn-danger delete-btn" 
                                                   style="padding: 0.4rem 0.8rem;"
                                                   onclick="return confirm('Are you sure you want to delete this category?');">Delete</a>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Add/Edit Form -->
                <div>
                    <div class="food-card" style="position: sticky; top: 100px;">
                        <div class="food-card-body" style="padding: 2rem;">
                            <h3 style="margin-bottom: 1.5rem;">
                                <?php echo $edit_category ? 'Edit Category' : 'Add New Category'; ?>
                            </h3>

                            <form method="POST" enctype="multipart/form-data">
                                <?php if ($edit_category): ?>
                                    <input type="hidden" name="category_id" value="<?php echo $edit_category['category_id']; ?>">
                                <?php endif; ?>

                                <div class="form-group">
                                    <label for="category_name">Category Name *</label>
                                    <input type="text" 
                                           id="category_name" 
                                           name="category_name" 
                                           class="form-control" 
                                           value="<?php echo $edit_category ? htmlspecialchars($edit_category['category_name']) : ''; ?>"
                                           required>
                                </div>

                                <div class="form-group">
                                    <label for="category_image">Category Image</label>
                                    <?php if ($edit_category && $edit_category['category_image']): ?>
                                        <div style="margin-bottom: 1rem;">
                                            <img src="../images/<?php echo $edit_category['category_image']; ?>" 
                                                 style="width: 100px; height: 100px; object-fit: cover; border-radius: 50%;">
                                        </div>
                                    <?php endif; ?>
                                    <input type="file" 
                                           id="category_image" 
                                           name="category_image" 
                                           class="form-control"
                                           accept="image/*">
                                </div>

                                <div class="form-group">
                                    <label for="featured">Featured</label>
                                    <select id="featured" name="featured" class="form-control">
                                        <option value="YES" <?php echo ($edit_category && $edit_category['featured'] === 'YES') ? 'selected' : ''; ?>>YES</option>
                                        <option value="NO" <?php echo ($edit_category && $edit_category['featured'] === 'NO') ? 'selected' : ''; ?>>NO</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="active">Active</label>
                                    <select id="active" name="active" class="form-control">
                                        <option value="YES" <?php echo ($edit_category && $edit_category['active'] === 'YES') ? 'selected' : ''; ?>>YES</option>
                                        <option value="NO" <?php echo ($edit_category && $edit_category['active'] === 'NO') ? 'selected' : ''; ?>>NO</option>
                                    </select>
                                </div>

                                <button type="submit" class="btn btn-primary btn-ripple" style="width: 100%;">
                                    <?php echo $edit_category ? 'Update Category' : 'Add Category'; ?>
                                </button>

                                <?php if ($edit_category): ?>
                                    <a href="manage-categories.php" class="btn btn-secondary" style="width: 100%; margin-top: 0.5rem; text-align: center; display: block;">
                                        Cancel Edit
                                    </a>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="../js/main.js"></script>
</body>
</html>