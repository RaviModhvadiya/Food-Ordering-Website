<?php
require_once '../config.php';
require_once '../functions.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect('pages/login.php');
}

$success = '';
$error = '';

// Handle Delete
if (isset($_GET['delete'])) {
    $user_id = (int)$_GET['delete'];
    
    // Don't allow deleting own account
    if ($user_id == $_SESSION['user_id']) {
        $error = 'You cannot delete your own account!';
    } else {
        $sql = "DELETE FROM users WHERE user_id = $user_id";
        if (mysqli_query($conn, $sql)) {
            $success = 'User deleted successfully!';
        } else {
            $error = 'Failed to delete user';
        }
    }
}

// Get all users
$sql = "SELECT * FROM users ORDER BY created_at DESC";
$result = mysqli_query($conn, $sql);

// Get statistics
$sql_customer_count = "SELECT COUNT(*) as total FROM users WHERE user_type = 'customer'";
$result_customer = mysqli_query($conn, $sql_customer_count);
$customer_count = mysqli_fetch_assoc($result_customer)['total'];

$sql_admin_count = "SELECT COUNT(*) as total FROM users WHERE user_type = 'admin'";
$result_admin = mysqli_query($conn, $sql_admin_count);
$admin_count = mysqli_fetch_assoc($result_admin)['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/animations.css">
    <link rel="stylesheet" href="../css/responsive.css">
</head>
<body>
    <!-- Admin Header -->
    <header style="background: linear-gradient(135deg, #2c3e50, #34495e);">
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">⚙️ Admin Panel</a>
                <button class="menu-toggle">☰</button>
                <ul class="nav-links">
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="manage-categories.php">Categories</a></li>
                    <li><a href="manage-foods.php">Foods</a></li>
                    <li><a href="manage-orders.php">Orders</a></li>
                    <li><a href="manage-users.php">Users</a></li>
                    <li><a href="../">View Website</a></li>
                    <li><a href="../actions/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="py-3">
        <div class="container">
            <?php if ($success): ?>
                <?php echo showSuccess($success); ?>
            <?php endif; ?>
            <?php if ($error): ?>
                <?php echo showError($error); ?>
            <?php endif; ?>

            <h2 style="margin-bottom: 2rem;">Manage Users</h2>

            <!-- Statistics -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; margin-bottom: 3rem;">
                <div class="food-card text-center">
                    <div class="food-card-body">
                        <div style="font-size: 2.5rem; color: var(--secondary-color); margin-bottom: 0.5rem;">👥</div>
                        <h3 style="font-size: 2rem; color: var(--secondary-color); margin-bottom: 0.3rem;"><?php echo mysqli_num_rows($result); ?></h3>
                        <p style="color: #666;">Total Users</p>
                    </div>
                </div>

                <div class="food-card text-center">
                    <div class="food-card-body">
                        <div style="font-size: 2.5rem; color: var(--success-color); margin-bottom: 0.5rem;">👤</div>
                        <h3 style="font-size: 2rem; color: var(--success-color); margin-bottom: 0.3rem;"><?php echo $customer_count; ?></h3>
                        <p style="color: #666;">Customers</p>
                    </div>
                </div>

                <div class="food-card text-center">
                    <div class="food-card-body">
                        <div style="font-size: 2.5rem; color: var(--warning-color); margin-bottom: 0.5rem;">⚙️</div>
                        <h3 style="font-size: 2rem; color: var(--warning-color); margin-bottom: 0.3rem;"><?php echo $admin_count; ?></h3>
                        <p style="color: #666;">Administrators</p>
                    </div>
                </div>
            </div>

            <!-- Users Table -->
            <div class="food-card">
                <div class="food-card-body">
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>User Type</th>
                                    <th>Joined Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                mysqli_data_seek($result, 0);
                                while ($user = mysqli_fetch_assoc($result)): 
                                ?>
                                <tr>
                                    <td><?php echo $user['user_id']; ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($user['full_name']); ?></strong>
                                        <?php if ($user['user_id'] == $_SESSION['user_id']): ?>
                                            <span class="badge badge-primary" style="margin-left: 0.5rem;">You</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td><?php echo htmlspecialchars($user['phone']); ?></td>
                                    <td>
                                        <?php if ($user['user_type'] === 'admin'): ?>
                                            <span class="badge badge-warning">Admin</span>
                                        <?php else: ?>
                                            <span class="badge badge-success">Customer</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo formatDate($user['created_at']); ?></td>
                                    <td>
                                        <button onclick="viewUserDetails(<?php echo $user['user_id']; ?>)" 
                                                class="btn btn-primary" 
                                                style="padding: 0.4rem 0.8rem; margin-right: 0.5rem;">
                                            View
                                        </button>
                                        
                                        <?php if ($user['user_id'] != $_SESSION['user_id']): ?>
                                            <a href="?delete=<?php echo $user['user_id']; ?>" 
                                               class="btn btn-danger delete-btn" 
                                               style="padding: 0.4rem 0.8rem;"
                                               onclick="return confirm('Are you sure you want to delete this user?');">
                                                Delete
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- User Details Modal -->
    <div id="userModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 10000; align-items: center; justify-content: center;">
        <div class="food-card" style="max-width: 600px; margin: 2rem; max-height: 90vh; overflow-y: auto;">
            <div class="food-card-body" style="padding: 2rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                    <h3>User Details</h3>
                    <button onclick="closeModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">✕</button>
                </div>
                <div id="userDetailsContent"></div>
            </div>
        </div>
    </div>

    <script src="../js/main.js"></script>
    <script>
        function viewUserDetails(userId) {
            showLoading();
            
            fetch('../actions/get-user-details.php?user_id=' + userId)
                .then(response => response.json())
                .then(data => {
                    hideLoading();
                    if (data.success) {
                        const user = data.user;
                        const content = `
                            <div style="background: #f8f9fa; padding: 1.5rem; border-radius: 10px; margin-bottom: 1rem;">
                                <h4 style="margin-bottom: 1rem;">Personal Information</h4>
                                <p><strong>Name:</strong> ${user.full_name}</p>
                                <p><strong>Email:</strong> ${user.email}</p>
                                <p><strong>Phone:</strong> ${user.phone}</p>
                                <p><strong>User Type:</strong> <span class="badge ${user.user_type === 'admin' ? 'badge-warning' : 'badge-success'}">${user.user_type}</span></p>
                                <p><strong>Joined:</strong> ${user.created_at}</p>
                            </div>
                            
                            <div style="background: #f8f9fa; padding: 1.5rem; border-radius: 10px; margin-bottom: 1rem;">
                                <h4 style="margin-bottom: 1rem;">Address</h4>
                                <p>${user.address || 'No address provided'}</p>
                            </div>
                            
                            <div style="background: #f8f9fa; padding: 1.5rem; border-radius: 10px;">
                                <h4 style="margin-bottom: 1rem;">Order Statistics</h4>
                                <p><strong>Total Orders:</strong> ${data.stats.total_orders}</p>
                                <p><strong>Total Spent:</strong> ₹${parseFloat(data.stats.total_spent || 0).toFixed(2)}</p>
                            </div>
                        `;
                        document.getElementById('userDetailsContent').innerHTML = content;
                        document.getElementById('userModal').style.display = 'flex';
                    } else {
                        showNotification('Failed to load user details', 'error');
                    }
                })
                .catch(error => {
                    hideLoading();
                    showNotification('An error occurred', 'error');
                });
        }

        function closeModal() {
            document.getElementById('userModal').style.display = 'none';
        }

        // Close modal on outside click
        document.getElementById('userModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });
    </script>
</body>
</html>