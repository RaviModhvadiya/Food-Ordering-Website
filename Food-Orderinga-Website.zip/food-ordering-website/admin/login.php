<?php
// Start session
session_start();

// Database connection
$conn = mysqli_connect('localhost', 'root', '', 'food_ordering');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$error = '';
$debug_info = '';

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $debug_info .= "Email entered: " . htmlspecialchars($email) . "<br>";
    $debug_info .= "Password entered: " . htmlspecialchars($password) . "<br><br>";

    if (empty($email) || empty($password)) {
        $error = 'Please fill in all fields';
    } else {
        // Simple query - no prepared statement for debugging
        $sql = "SELECT * FROM users WHERE email = '" . mysqli_real_escape_string($conn, $email) . "'";
        $result = mysqli_query($conn, $sql);

        $debug_info .= "Query: " . $sql . "<br>";
        $debug_info .= "Rows found: " . mysqli_num_rows($result) . "<br><br>";

        if (mysqli_num_rows($result) > 0) {
            $user = mysqli_fetch_assoc($result);

            $debug_info .= "User found!<br>";
            $debug_info .= "User Type: " . $user['user_type'] . "<br>";
            $debug_info .= "DB Password (first 20 chars): " . substr($user['password'], 0, 20) . "...<br><br>";

            // Check if admin
            if ($user['user_type'] !== 'admin') {
                $error = 'Access denied. Admin only.';
                $debug_info .= "ERROR: User is not admin!<br>";
            } else {
                // Check password - try multiple methods
                $password_match = false;

                // Method 1: Plain text
                if ($password === $user['password']) {
                    $password_match = true;
                    $debug_info .= "✅ Password matched (plain text)<br>";
                }

                // Method 2: Password hash
                if (password_verify($password, $user['password'])) {
                    $password_match = true;
                    $debug_info .= "✅ Password matched (hashed)<br>";
                }

                if ($password_match) {
                    // SUCCESS! Set session
                    $_SESSION['user_id'] = $user['user_id'];
                    $_SESSION['user_name'] = $user['full_name'];
                    $_SESSION['user_email'] = $user['email'];
                    $_SESSION['user_type'] = $user['user_type'];

                    $debug_info .= "<br>🎉 SESSION SET SUCCESSFULLY!<br>";
                    $debug_info .= "Redirecting to index.php...<br>";

                    // Redirect
                    header("Location: index.php");
                    exit();
                } else {
                    $error = 'Invalid password';
                    $debug_info .= "❌ Password did NOT match<br>";
                }
            }
        } else {
            $error = 'User not found';
            $debug_info .= "❌ No user found with this email<br>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - FIXED VERSION</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            max-width: 900px;
            width: 100%;
            display: grid;
            margin-left: 30%;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            align-items: center;
        }

        .login-box,
        .debug-box {
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }

        .login-box {
            text-align: center;
        }

        .icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 40px;
            color: white;
        }

        h1 {
            color: #2c3e50;
            margin-bottom: 10px;
            font-size: 28px;
        }

        .subtitle {
            color: #666;
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
        }

        input {
            width: 100%;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: border 0.3s;
        }

        input:focus {
            outline: none;
            border-color: #667eea;
        }

        button {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s;
        }

        button:hover {
            transform: translateY(-2px);
        }

        .error {
            background: #fee;
            color: #c00;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 2px solid #fcc;
        }

        .demo-creds {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            font-size: 14px;
        }

        .demo-creds code {
            background: white;
            padding: 2px 8px;
            border-radius: 4px;
            font-family: monospace;
            color: #667eea;
        }

        .debug-box {
            background: #2c3e50;
            color: white;
            max-height: 600px;
            overflow-y: auto;
        }

        .debug-box h2 {
            color: #fff;
            margin-bottom: 20px;
            font-size: 20px;
        }

        .debug-info {
            background: #34495e;
            padding: 15px;
            border-radius: 8px;
            font-family: monospace;
            font-size: 14px;
            line-height: 1.8;
        }

        .sql-fix {
            background: #f39c12;
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
        }

        .sql-fix h3 {
            margin-bottom: 10px;
        }

        textarea {
            width: 100%;
            height: 150px;
            padding: 10px;
            border-radius: 5px;
            border: none;
            font-family: monospace;
            margin-top: 10px;
        }

        @media (max-width: 768px) {
            .container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <!-- Login Form -->
        <div class="login-box">
            <div class="icon">⚙️</div>
            <h1>Admin Panel</h1>
            <p class="subtitle">FoodOrder System</p>

            <?php if ($error): ?>
                <div class="error">
                    <strong>❌ Error:</strong> <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email"
                        id="email"
                        name="email"
                        value="admin@foodorder.com"
                        required
                        autofocus>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password"
                        id="password"
                        name="password"
                        value="admin123"
                        required>
                </div>

                <button type="submit">🔐 Login to Admin Panel</button>
            </form>
        </div>
    </div>
</body>

</html>