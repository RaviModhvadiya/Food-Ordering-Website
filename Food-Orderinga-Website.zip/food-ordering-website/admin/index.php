<?php
require_once '../config.php';

// Define essential functions if not loaded from functions.php
if (!function_exists('isLoggedIn')) {
    function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }
}

if (!function_exists('isAdmin')) {
    function isAdmin() {
        return isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'admin';
    }
}

if (!function_exists('formatPrice')) {
    function formatPrice($price) {
        return '₹' . number_format($price, 2);
    }
}

if (!function_exists('formatDate')) {
    function formatDate($date) {
        return date('d M Y', strtotime($date));
    }
}

// Check if user is admin
if (!isLoggedIn() || !isAdmin()) {
    $_SESSION['error_message'] = 'Access denied. Admin only.';
    header("Location: login.php");
    exit();
}

// Get statistics
$sql_total_orders = "SELECT COUNT(*) as total FROM orders";
$result_orders = mysqli_query($conn, $sql_total_orders);
$total_orders = mysqli_fetch_assoc($result_orders)['total'];

$sql_total_revenue = "SELECT SUM(total_amount) as revenue FROM orders WHERE order_status != 'Cancelled'";
$result_revenue = mysqli_query($conn, $sql_total_revenue);
$total_revenue = mysqli_fetch_assoc($result_revenue)['revenue'] ?? 0;

$sql_total_users = "SELECT COUNT(*) as total FROM users WHERE user_type = 'customer'";
$result_users = mysqli_query($conn, $sql_total_users);
$total_users = mysqli_fetch_assoc($result_users)['total'];

$sql_total_foods = "SELECT COUNT(*) as total FROM food_items WHERE active = 'YES'";
$result_foods = mysqli_query($conn, $sql_total_foods);
$total_foods = mysqli_fetch_assoc($result_foods)['total'];

// Get recent orders
$sql_recent = "SELECT o.*, u.full_name FROM orders o 
               JOIN users u ON o.user_id = u.user_id 
               ORDER BY o.order_date DESC LIMIT 10";
$result_recent = mysqli_query($conn, $sql_recent);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?php echo defined('SITE_NAME') ? SITE_NAME : 'FoodOrder'; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/animations.css">
    <link rel="stylesheet" href="../css/responsive.css">
    <link rel="stylesheet" href="css/admin-style.css">
    <style>
        /* Inline styles for missing CSS */
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
        .navbar { display: flex; justify-content: space-between; align-items: center; padding: 1rem 0; }
        .logo { font-size: 1.5rem; font-weight: bold; color: white; text-decoration: none; }
        .nav-links { display: flex; list-style: none; gap: 1.5rem; margin: 0; padding: 0; }
        .nav-links a { color: white; text-decoration: none; }
        .nav-links a:hover { opacity: 0.8; }
        .py-3 { padding: 3rem 0; }
        .section-title { text-align: center; margin-bottom: 2rem; }
        .section-title h2 { font-size: 2rem; margin-bottom: 0.5rem; }
        .food-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem; }
        .food-card { background: white; border-radius: 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); overflow: hidden; }
        .food-card-body { padding: 1.5rem; }
        .text-center { text-align: center; }
        .animate-scale { animation: scaleIn 0.3s ease; }
        @keyframes scaleIn { from { transform: scale(0.9); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f8f9fa; font-weight: 600; }
        .badge { padding: 0.4rem 0.8rem; border-radius: 20px; font-size: 0.85rem; font-weight: 600; display: inline-block; }
        .badge-primary { background: #007bff; color: white; }
        .badge-warning { background: #ffc107; color: #333; }
        .badge-success { background: #28a745; color: white; }
        .badge-danger { background: #dc3545; color: white; }
        .btn { padding: 0.5rem 1rem; border: none; border-radius: 5px; text-decoration: none; display: inline-block; cursor: pointer; }
        .btn-primary { background: #007bff; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .btn:hover { opacity: 0.9; }
        .hover-lift { transition: transform 0.3s ease, box-shadow 0.3s ease; }
        .hover-lift:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.15); }
        :root {
            --primary-color: #007bff;
            --secondary-color: #6c757d;
            --success-color: #28a745;
            --warning-color: #ffc107;
        }
    </style>
</head>
<body>
    <!-- Admin Header -->
    <header style="background: linear-gradient(135deg, #2c3e50, #34495e);">
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    ⚙️ Admin Panel
                </a>

                <ul class="nav-links">
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="manage-categories.php">Categories</a></li>
                    <li><a href="manage-foods.php">Foods</a></li>
                    <li><a href="manage-orders.php">Orders</a></li>
                    <li><a href="manage-users.php">Users</a></li>
                    <li><a href="../">View Website</a></li>
                    <li><a href="../actions/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="py-3">
        <div class="container">
            <div class="section-title">
                <h2>Dashboard</h2>
                <p>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</p>
            </div>

            <!-- Statistics Cards -->
            <div class="food-grid" style="margin-bottom: 3rem;">
                <div class="food-card text-center animate-scale">
                    <div class="food-card-body">
                        <div style="font-size: 3rem; color: var(--primary-color); margin-bottom: 0.5rem;">📦</div>
                        <h2 style="font-size: 2.5rem; color: var(--primary-color); margin-bottom: 0.5rem;"><?php echo $total_orders; ?></h2>
                        <p style="font-size: 1.1rem; color: #666;">Total Orders</p>
                    </div>
                </div>

                <div class="food-card text-center animate-scale">
                    <div class="food-card-body">
                        <div style="font-size: 3rem; color: var(--success-color); margin-bottom: 0.5rem;">💰</div>
                        <h2 style="font-size: 2.5rem; color: var(--success-color); margin-bottom: 0.5rem;"><?php echo formatPrice($total_revenue); ?></h2>
                        <p style="font-size: 1.1rem; color: #666;">Total Revenue</p>
                    </div>
                </div>

                <div class="food-card text-center animate-scale">
                    <div class="food-card-body">
                        <div style="font-size: 3rem; color: var(--secondary-color); margin-bottom: 0.5rem;">👥</div>
                        <h2 style="font-size: 2.5rem; color: var(--secondary-color); margin-bottom: 0.5rem;"><?php echo $total_users; ?></h2>
                        <p style="font-size: 1.1rem; color: #666;">Total Users</p>
                    </div>
                </div>

                <div class="food-card text-center animate-scale">
                    <div class="food-card-body">
                        <div style="font-size: 3rem; color: var(--warning-color); margin-bottom: 0.5rem;">🍕</div>
                        <h2 style="font-size: 2.5rem; color: var(--warning-color); margin-bottom: 0.5rem;"><?php echo $total_foods; ?></h2>
                        <p style="font-size: 1.1rem; color: #666;">Active Foods</p>
                    </div>
                </div>
            </div>

            <!-- Recent Orders -->
            <div class="food-card">
                <div class="food-card-body" style="padding: 2rem;">
                    <h3 style="margin-bottom: 1.5rem;">Recent Orders</h3>

                    <?php if (mysqli_num_rows($result_recent) > 0): ?>
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Customer</th>
                                        <th>Total</th>
                                        <th>Payment</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($order = mysqli_fetch_assoc($result_recent)): ?>
                                        <tr>
                                            <td><strong>#<?php echo $order['order_id']; ?></strong></td>
                                            <td><?php echo htmlspecialchars($order['full_name']); ?></td>
                                            <td><strong><?php echo formatPrice($order['total_amount']); ?></strong></td>
                                            <td><?php echo htmlspecialchars($order['payment_method']); ?></td>
                                            <td>
                                                <?php
                                                $status_class = '';
                                                switch ($order['order_status']) {
                                                    case 'Ordered':
                                                        $status_class = 'badge-primary';
                                                        break;
                                                    case 'Processing':
                                                        $status_class = 'badge-warning';
                                                        break;
                                                    case 'Delivered':
                                                        $status_class = 'badge-success';
                                                        break;
                                                    case 'Cancelled':
                                                        $status_class = 'badge-danger';
                                                        break;
                                                }
                                                ?>
                                                <span class="badge <?php echo $status_class; ?>">
                                                    <?php echo $order['order_status']; ?>
                                                </span>
                                            </td>
                                            <td><?php echo formatDate($order['order_date']); ?></td>
                                            <td>
                                                <a href="manage-orders.php?order_id=<?php echo $order['order_id']; ?>" 
                                                   class="btn btn-primary" 
                                                   style="padding: 0.4rem 0.8rem; font-size: 0.9rem;">
                                                    View
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>

                        <div style="text-align: center; margin-top: 2rem;">
                            <a href="manage-orders.php" class="btn btn-secondary">View All Orders</a>
                        </div>

                    <?php else: ?>
                        <p class="text-center" style="color: #666; padding: 2rem;">No orders yet</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Quick Actions -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem; margin-top: 3rem;">
                <a href="manage-foods.php?action=add" class="food-card hover-lift" style="text-decoration: none; color: inherit;">
                    <div class="food-card-body text-center">
                        <div style="font-size: 3rem; margin-bottom: 0.5rem;">➕</div>
                        <h3>Add New Food</h3>
                        <p style="color: #666;">Add new food item to menu</p>
                    </div>
                </a>

                <a href="manage-categories.php?action=add" class="food-card hover-lift" style="text-decoration: none; color: inherit;">
                    <div class="food-card-body text-center">
                        <div style="font-size: 3rem; margin-bottom: 0.5rem;">📁</div>
                        <h3>Add Category</h3>
                        <p style="color: #666;">Create new food category</p>
                    </div>
                </a>

                <a href="manage-orders.php" class="food-card hover-lift" style="text-decoration: none; color: inherit;">
                    <div class="food-card-body text-center">
                        <div style="font-size: 3rem; margin-bottom: 0.5rem;">📋</div>
                        <h3>Manage Orders</h3>
                        <p style="color: #666;">View and update orders</p>
                    </div>
                </a>

                <a href="manage-users.php" class="food-card hover-lift" style="text-decoration: none; color: inherit;">
                    <div class="food-card-body text-center">
                        <div style="font-size: 3rem; margin-bottom: 0.5rem;">👤</div>
                        <h3>Manage Users</h3>
                        <p style="color: #666;">View and manage users</p>
                    </div>
                </a>
            </div>
        </div>
    </section>

    <script src="../js/main.js"></script>
</body>
</html>