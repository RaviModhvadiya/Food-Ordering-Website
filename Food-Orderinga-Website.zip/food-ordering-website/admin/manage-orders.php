<?php
require_once '../config.php';
require_once '../functions.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect('pages/login.php');
}

// Get filter
$status_filter = isset($_GET['status']) ? sanitize($_GET['status']) : '';

// Get all orders with filter
$sql = "SELECT o.*, u.full_name, u.email FROM orders o 
        JOIN users u ON o.user_id = u.user_id";

if (!empty($status_filter)) {
    $sql .= " WHERE o.order_status = '$status_filter'";
}

$sql .= " ORDER BY o.order_date DESC";
$result = mysqli_query($conn, $sql);

// Get order details if viewing specific order
$view_order = null;
$order_items = null;
if (isset($_GET['view'])) {
    $order_id = (int)$_GET['view'];
    $sql_order = "SELECT o.*, u.full_name, u.email, u.phone FROM orders o 
                  JOIN users u ON o.user_id = u.user_id 
                  WHERE o.order_id = $order_id";
    $result_order = mysqli_query($conn, $sql_order);
    $view_order = mysqli_fetch_assoc($result_order);
    
    if ($view_order) {
        $sql_items = "SELECT oi.*, f.food_name, f.image_name 
                      FROM order_items oi 
                      JOIN food_items f ON oi.food_id = f.food_id 
                      WHERE oi.order_id = $order_id";
        $order_items = mysqli_query($conn, $sql_items);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders - Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/animations.css">
    <link rel="stylesheet" href="../css/responsive.css">
</head>
<body>
    <!-- Admin Header -->
    <header style="background: linear-gradient(135deg, #2c3e50, #34495e);">
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">⚙️ Admin Panel</a>
                <button class="menu-toggle">☰</button>
                <ul class="nav-links">
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="manage-categories.php">Categories</a></li>
                    <li><a href="manage-foods.php">Foods</a></li>
                    <li><a href="manage-orders.php">Orders</a></li>
                    <li><a href="manage-users.php">Users</a></li>
                    <li><a href="../">View Website</a></li>
                    <li><a href="../actions/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="py-3">
        <div class="container">
            <?php if ($view_order): ?>
                <!-- Order Details View -->
                <div style="margin-bottom: 2rem;">
                    <a href="manage-orders.php" class="btn btn-secondary">← Back to Orders</a>
                </div>

                <div class="food-card">
                    <div class="food-card-body" style="padding: 2rem;">
                        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 2rem; padding-bottom: 1rem; border-bottom: 2px solid #eee;">
                            <div>
                                <h2>Order #<?php echo $view_order['order_id']; ?></h2>
                                <p style="color: #666; margin-top: 0.5rem;">
                                    Placed on <?php echo formatDate($view_order['order_date']); ?>
                                </p>
                            </div>
                            <div style="text-align: right;">
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Update Status:</label>
                                <select class="form-control" style="width: 200px;"
                                        onchange="updateOrderStatus(<?php echo $view_order['order_id']; ?>, this.value)">
                                    <option value="Ordered" <?php echo $view_order['order_status'] === 'Ordered' ? 'selected' : ''; ?>>Ordered</option>
                                    <option value="Processing" <?php echo $view_order['order_status'] === 'Processing' ? 'selected' : ''; ?>>Processing</option>
                                    <option value="Delivered" <?php echo $view_order['order_status'] === 'Delivered' ? 'selected' : ''; ?>>Delivered</option>
                                    <option value="Cancelled" <?php echo $view_order['order_status'] === 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                            </div>
                        </div>

                        <!-- Customer Info -->
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin-bottom: 2rem;">
                            <div style="background: #f8f9fa; padding: 1.5rem; border-radius: 10px;">
                                <h3 style="margin-bottom: 1rem;">Customer Details</h3>
                                <p><strong>Name:</strong> <?php echo htmlspecialchars($view_order['full_name']); ?></p>
                                <p><strong>Email:</strong> <?php echo htmlspecialchars($view_order['email']); ?></p>
                                <p><strong>Phone:</strong> <?php echo htmlspecialchars($view_order['contact_phone']); ?></p>
                            </div>

                            <div style="background: #f8f9fa; padding: 1.5rem; border-radius: 10px;">
                                <h3 style="margin-bottom: 1rem;">Delivery Information</h3>
                                <p><strong>Address:</strong></p>
                                <p style="color: #666;"><?php echo nl2br(htmlspecialchars($view_order['delivery_address'])); ?></p>
                                <p style="margin-top: 1rem;"><strong>Payment:</strong> <?php echo htmlspecialchars($view_order['payment_method']); ?></p>
                            </div>
                        </div>

                        <!-- Order Items -->
                        <h3 style="margin-bottom: 1rem;">Order Items</h3>
                        <div style="margin-bottom: 2rem;">
                            <?php while ($item = mysqli_fetch_assoc($order_items)): ?>
                                <div style="display: flex; align-items: center; gap: 1rem; padding: 1rem; background: #f8f9fa; border-radius: 10px; margin-bottom: 1rem;">
                                    <img src="../images/foods/<?php echo $item['image_name'] ?: 'default-food.jpg'; ?>" 
                                         alt="<?php echo htmlspecialchars($item['food_name']); ?>"
                                         style="width: 80px; height: 80px; object-fit: cover; border-radius: 8px;">
                                    <div style="flex: 1;">
                                        <strong style="font-size: 1.1rem;"><?php echo htmlspecialchars($item['food_name']); ?></strong>
                                        <p style="color: #666; margin-top: 0.3rem;">
                                            Quantity: <?php echo $item['quantity']; ?> × <?php echo formatPrice($item['price']); ?>
                                        </p>
                                    </div>
                                    <strong style="color: var(--primary-color); font-size: 1.2rem;">
                                        <?php echo formatPrice($item['subtotal']); ?>
                                    </strong>
                                </div>
                            <?php endwhile; ?>
                        </div>

                        <!-- Order Total -->
                        <div style="border-top: 2px solid #eee; padding-top: 1rem; max-width: 400px; margin-left: auto;">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 0.8rem;">
                                <span>Subtotal:</span>
                                <span><?php echo formatPrice($view_order['total_amount'] - 30); ?></span>
                            </div>
                            <div style="display: flex; justify-content: space-between; margin-bottom: 0.8rem;">
                                <span>Delivery Fee:</span>
                                <span><?php echo formatPrice(30); ?></span>
                            </div>
                            <div style="display: flex; justify-content: space-between; font-size: 1.4rem; font-weight: bold; border-top: 2px solid #eee; padding-top: 1rem; color: var(--primary-color);">
                                <span>Total Amount:</span>
                                <span><?php echo formatPrice($view_order['total_amount']); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

            <?php else: ?>
                <!-- Orders List -->
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                    <h2>Manage Orders</h2>
                    
                    <!-- Filter -->
                    <div style="display: flex; gap: 1rem; align-items: center;">
                        <label style="font-weight: bold;">Filter by Status:</label>
                        <select class="form-control" style="width: 200px;" onchange="window.location.href='?status=' + this.value">
                            <option value="">All Orders</option>
                            <option value="Ordered" <?php echo $status_filter === 'Ordered' ? 'selected' : ''; ?>>Ordered</option>
                            <option value="Processing" <?php echo $status_filter === 'Processing' ? 'selected' : ''; ?>>Processing</option>
                            <option value="Delivered" <?php echo $status_filter === 'Delivered' ? 'selected' : ''; ?>>Delivered</option>
                            <option value="Cancelled" <?php echo $status_filter === 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>
                </div>

                <div class="food-card">
                    <div class="food-card-body">
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Customer</th>
                                        <th>Email</th>
                                        <th>Total Amount</th>
                                        <th>Payment Method</th>
                                        <th>Status</th>
                                        <th>Order Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (mysqli_num_rows($result) > 0): ?>
                                        <?php while ($order = mysqli_fetch_assoc($result)): ?>
                                        <tr>
                                            <td><strong>#<?php echo $order['order_id']; ?></strong></td>
                                            <td><?php echo htmlspecialchars($order['full_name']); ?></td>
                                            <td><?php echo htmlspecialchars($order['email']); ?></td>
                                            <td><strong><?php echo formatPrice($order['total_amount']); ?></strong></td>
                                            <td><?php echo htmlspecialchars($order['payment_method']); ?></td>
                                            <td>
                                                <select class="form-control" style="padding: 0.4rem; min-width: 130px;"
                                                        onchange="updateOrderStatus(<?php echo $order['order_id']; ?>, this.value)">
                                                    <option value="Ordered" <?php echo $order['order_status'] === 'Ordered' ? 'selected' : ''; ?>>Ordered</option>
                                                    <option value="Processing" <?php echo $order['order_status'] === 'Processing' ? 'selected' : ''; ?>>Processing</option>
                                                    <option value="Delivered" <?php echo $order['order_status'] === 'Delivered' ? 'selected' : ''; ?>>Delivered</option>
                                                    <option value="Cancelled" <?php echo $order['order_status'] === 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                                </select>
                                            </td>
                                            <td><?php echo formatDate($order['order_date']); ?></td>
                                            <td>
                                                <a href="?view=<?php echo $order['order_id']; ?>" 
                                                   class="btn btn-primary" 
                                                   style="padding: 0.4rem 0.8rem;">View Details</a>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="8" class="text-center" style="padding: 2rem; color: #666;">
                                                No orders found
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <script src="../js/main.js"></script>
    <script>
        function updateOrderStatus(orderId, status) {
            if (confirm('Update order status to: ' + status + '?')) {
                showLoading();
                
                fetch('../actions/update-order-status.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'order_id=' + orderId + '&status=' + status
                })
                .then(response => response.json())
                .then(data => {
                    hideLoading();
                    if (data.success) {
                        showNotification('Order status updated successfully!', 'success');
                        setTimeout(() => location.reload(), 1500);
                    } else {
                        showNotification('Failed to update status', 'error');
                    }
                })
                .catch(error => {
                    hideLoading();
                    showNotification('An error occurred', 'error');
                });
            }
        }
    </script>
</body>
</html>