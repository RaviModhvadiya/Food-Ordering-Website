// Get the base URL from the page
const SITE_URL = window.location.origin + '/food-ordering-website/';

// Add to Cart
function addToCart(foodId, foodName, price) {
    showLoading();

    fetch(SITE_URL + 'actions/add-to-cart.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `food_id=${foodId}`
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            hideLoading();
            if (data.success) {
                showNotification(`${foodName} added to cart!`, 'success');
                updateCartCount(data.cart_count);
                animateCartIcon();
            } else {
                showNotification(data.message || 'Failed to add item to cart', 'error');
            }
        })
        .catch(error => {
            hideLoading();
            showNotification('An error occurred. Please try again.', 'error');
            console.error('Error:', error);
        });
}

// Update Cart Count in UI
function updateCartCount(count) {
    const cartCountElements = document.querySelectorAll('.cart-count');
    cartCountElements.forEach(element => {
        element.textContent = count;
        element.classList.add('animate-pulse');
        setTimeout(() => element.classList.remove('animate-pulse'), 500);
    });
}

// Update Cart Total in UI
function updateCartTotal(total) {
    const cartTotalElement = document.getElementById('cart-total');
    if (cartTotalElement) {
        cartTotalElement.textContent = formatPrice(total);
        cartTotalElement.classList.add('animate-pulse');
        setTimeout(() => cartTotalElement.classList.remove('animate-pulse'), 500);
    }
}

// Update Item Subtotal in UI
function updateItemSubtotal(foodId, subtotal) {
    const subtotalElement = document.getElementById(`subtotal-${foodId}`);
    if (subtotalElement) {
        subtotalElement.textContent = formatPrice(subtotal);
        subtotalElement.classList.add('animate-pulse');
        setTimeout(() => subtotalElement.classList.remove('animate-pulse'), 500);
    }
}

// Animate Cart Icon when item added
function animateCartIcon() {
    const cartIcon = document.querySelector('.cart-icon');
    if (cartIcon) {
        cartIcon.classList.add('animate-bounce');
        setTimeout(() => cartIcon.classList.remove('animate-bounce'), 1000);
    }
}

// Remove from Cart
function removeFromCart(foodId) {
    if (!confirm('Remove this item from cart?')) {
        return;
    }

    showLoading();

    fetch(SITE_URL + 'actions/remove-from-cart.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `food_id=${foodId}`
    })
        .then(response => response.json())
        .then(data => {
            hideLoading();
            if (data.success) {
                showNotification('Item removed from cart', 'success');
                updateCartCount(data.cart_count);
                updateCartTotal(data.cart_total);

                // Remove item from DOM
                const cartItem = document.getElementById(`cart-item-${foodId}`);
                if (cartItem) {
                    cartItem.style.opacity = '0';
                    setTimeout(() => cartItem.remove(), 300);
                }

                // Show empty cart message if no items
                if (data.cart_count === 0) {
                    location.reload();
                }
            } else {
                showNotification(data.message || 'Failed to remove item', 'error');
            }
        })
        .catch(error => {
            hideLoading();
            showNotification('An error occurred', 'error');
            console.error('Error:', error);
        });
}

// Update Cart Quantity
function updateCartQuantity(foodId, quantity) {
    if (quantity < 1) {
        removeFromCart(foodId);
        return;
    }

    fetch(SITE_URL + 'actions/update-cart.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `food_id=${foodId}&quantity=${quantity}`
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateCartCount(data.cart_count);
                updateCartTotal(data.cart_total);
                updateItemSubtotal(foodId, data.item_subtotal);
            } else {
                showNotification(data.message || 'Failed to update quantity', 'error');
            }
        })
        .catch(error => {
            showNotification('An error occurred', 'error');
            console.error('Error:', error);
        });
}

// Initialize Cart Page Functionality
document.addEventListener('DOMContentLoaded', function () {
    // Quantity input handlers on cart page
    const quantityInputs = document.querySelectorAll('.cart-quantity-input');
    quantityInputs.forEach(input => {
        input.addEventListener('change', debounce(function () {
            const foodId = this.dataset.foodId;
            const quantity = parseInt(this.value);
            updateCartQuantity(foodId, quantity);
        }, 500));
    });

    // Remove buttons
    const removeButtons = document.querySelectorAll('.remove-cart-item');
    removeButtons.forEach(button => {
        button.addEventListener('click', function () {
            const foodId = this.dataset.foodId;
            removeFromCart(foodId);
        });
    });

    // Checkout form validation
    const checkoutForm = document.getElementById('checkout-form');
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', function (e) {
            const paymentMethod = document.querySelector('input[name="payment_method"]:checked');
            if (!paymentMethod) {
                e.preventDefault();
                showNotification('Please select a payment method', 'error');
                return false;
            }

            const deliveryAddress = document.getElementById('delivery_address');
            const contactPhone = document.getElementById('contact_phone');

            if (!deliveryAddress.value.trim()) {
                e.preventDefault();
                showNotification('Please enter delivery address', 'error');
                deliveryAddress.focus();
                return false;
            }

            if (!contactPhone.value.trim()) {
                e.preventDefault();
                showNotification('Please enter contact phone', 'error');
                contactPhone.focus();
                return false;
            }

            showLoading();
        });
    }
});

// Clear Cart
function clearCart() {
    if (!confirm('Are you sure you want to clear your cart?')) {
        return;
    }

    showLoading();

    fetch(SITE_URL + 'actions/clear-cart.php', {
        method: 'POST'
    })
        .then(response => response.json())
        .then(data => {
            hideLoading();
            if (data.success) {
                showNotification('Cart cleared', 'success');
                setTimeout(() => location.reload(), 1000);
            } else {
                showNotification('Failed to clear cart', 'error');
            }
        })
        .catch(error => {
            hideLoading();
            showNotification('An error occurred', 'error');
            console.error('Error:', error);
        });
}